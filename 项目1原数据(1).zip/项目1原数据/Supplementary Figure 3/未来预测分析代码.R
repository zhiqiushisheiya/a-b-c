setwd("C:/Users/22975/Desktop/figure7")
library(forecast)
library(ggplot2)
library(readxl)
library(ggpubr)
library(showtext)


font_add("Times New Roman", "times.ttf")
showtext_auto() 

IHD_ASIR=read_excel("数据.xlsx",sheet=2)
IHD_ASIR_ts=ts(IHD_ASIR$val,start=1990,frequency=1)
plot(IHD_ASIR_ts)


fit1=auto.arima(IHD_ASIR_ts)
fit1
summary(fit1)

forecasted_values1=forecast(fit1,h=29)
forecast_df1=data.frame(
  year=c(time(IHD_ASIR_ts),time(forecasted_values1$mean)),
  value=c(as.numeric(IHD_ASIR_ts),as.numeric(forecasted_values1$mean)),
  Type=c(rep("Actual",length(IHD_ASIR_ts)),rep("Forecast",length(forecasted_values1$mean)))
)

p1=ggplot()+
  geom_line(data=forecast_df1,aes(x=year,y=value,color=Type),size=0.5)+
  geom_line(data = forecast_df1[forecast_df1$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5)+
  geom_point(data=forecast_df1[forecast_df1$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5,shape=21,
             fill="yellow",color="darkgray",stroke=0.5)+
  geom_ribbon(data=data.frame(
    year=time(forecasted_values1$mean),
    ymin=forecasted_values1$lower[,2],
    ymax=forecasted_values1$upper[,2]
  ),aes(x=year,ymin=ymin,ymax=ymax),fill="yellow",alpha=0.2)+
  geom_vline(xintercept = 2021,linetype="dashed",color="black",size=1)+
  scale_color_manual(values=c("Actual"="red","Forecast"="yellow"))+
  labs(title="ASIR of IHD",x="Year",y="ASIR(per 100,000)")+
  ylim(300,450)+
  theme_minimal()+
  theme(text = element_text(family = "Times New Roman", size = 10),
        axis.line = element_line(color = "darkgray"),
        plot.title = element_text(hjust = 0.5,vjust=1,face="bold",size=14),
        plot.margin = margin(3,3,3,3),
        axis.title.y = element_text(margin = margin(r = 10)))
plot(p1)   







IHD_ASPR=read_excel("数据.xlsx",sheet=3)
IHD_ASPR_ts=ts(IHD_ASPR$val,start=1990,frequency=1)
plot(IHD_ASPR_ts)


fit2=auto.arima(IHD_ASPR_ts)
fit2
summary(fit2)

fit2 <- auto.arima(
  IHD_ASPR_ts,
  d = 1,
  stepwise = FALSE,
  approximation = FALSE
)

forecasted_values2=forecast(fit2,h=29)
forecast_df2=data.frame(
  year=c(time(IHD_ASPR_ts),time(forecasted_values2$mean)),
  value=c(as.numeric(IHD_ASPR_ts),as.numeric(forecasted_values2$mean)),
  Type=c(rep("Actual",length(IHD_ASPR_ts)),rep("Forecast",length(forecasted_values2$mean)))
)

p2=ggplot()+
  geom_line(data=forecast_df2,aes(x=year,y=value,color=Type),size=0.5)+
  geom_line(data = forecast_df2[forecast_df2$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5)+
  geom_point(data=forecast_df2[forecast_df2$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5,shape=21,
             fill="yellow",color="darkgray",stroke=0.5)+
  geom_ribbon(data=data.frame(
    year=time(forecasted_values2$mean),
    ymin=forecasted_values2$lower[,2],
    ymax=forecasted_values2$upper[,2]
  ),aes(x=year,ymin=ymin,ymax=ymax),fill="yellow",alpha=0.2)+
  geom_vline(xintercept = 2021,linetype="dashed",color="black",size=1)+
  scale_color_manual(values=c("Actual"="red","Forecast"="yellow"))+
  labs(title="ASPR of IHD",x="Year",y="ASPR(per 100,000)")+
  ylim(2800,4000)+
  theme_minimal() +
  theme(
    text = element_text(family = "Times New Roman", size = 10),
    axis.line = element_line(color = "darkgray"),
    plot.title = element_text(hjust = 0.5, vjust = 1, face = "bold", size = 14),
    plot.margin = margin(3, 3, 3, 3),
    axis.title.y = element_text(margin = margin(r = 10)),
    # 同时设置横纵坐标刻度标签为加粗、黑色
    axis.text = element_text(face = "bold", color = "black")
  )
plot(p2)   




# 创建包含预测值和95% UI的详细数据框
forecast_details_df2 <- data.frame(
  year = time(forecasted_values2$mean),
  forecast_mean = as.numeric(forecasted_values2$mean),
  lower_95 = forecasted_values2$lower[,2],
  upper_95 = forecasted_values2$upper[,2],
  lower_80 = forecasted_values2$lower[,1],  # 80%置信区间（可选）
  upper_80 = forecasted_values2$upper[,1]   # 80%置信区间（可选）
)

# 查看前几行
head(forecast_details_df2)

# 查看后几行
tail(forecast_details_df2)

# 保存到CSV文件
write.csv(forecast_details_df2, "IHD_ASPR_forecast_with_95UI.csv", row.names = FALSE)



IHD_ASDR=read_excel("数据.xlsx",sheet=4)
IHD_ASDR_ts=ts(IHD_ASDR$val,start=1990,frequency=1)
plot(IHD_ASDR_ts)


fit3=auto.arima(IHD_ASDR_ts)
fit3
summary(fit3)

forecasted_values3=forecast(fit3,h=29)
forecast_df3=data.frame(
  year=c(time(IHD_ASDR_ts),time(forecasted_values3$mean)),
  value=c(as.numeric(IHD_ASDR_ts),as.numeric(forecasted_values3$mean)),
  Type=c(rep("Actual",length(IHD_ASDR_ts)),rep("Forecast",length(forecasted_values3$mean)))
)

p3=ggplot()+
  geom_line(data=forecast_df3,aes(x=year,y=value,color=Type),size=0.5)+
  geom_line(data = forecast_df3[forecast_df1$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5)+
  geom_point(data=forecast_df3[forecast_df1$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5,shape=21,
             fill="yellow",color="darkgray",stroke=0.5)+
  geom_ribbon(data=data.frame(
    year=time(forecasted_values3$mean),
    ymin=forecasted_values3$lower[,2],
    ymax=forecasted_values3$upper[,2]
  ),aes(x=year,ymin=ymin,ymax=ymax),fill="yellow",alpha=0.2)+
  geom_vline(xintercept = 2021,linetype="dashed",color="black",size=1)+
  scale_color_manual(values=c("Actual"="red","Forecast"="yellow"))+
  labs(title="ASMR of IHD",x="Year",y="ASMR(per 100,000)")+
  ylim(40,170)+
  theme_minimal()+
  theme(text = element_text(family = "Times New Roman", size = 10),
        axis.line = element_line(color = "darkgray"),
        plot.title = element_text(hjust = 0.5,vjust=1,face="bold",size=14),
        plot.margin = margin(3,3,3,3),
        axis.title.y = element_text(margin = margin(r = 10)))
plot(p3) 





IHD_ASDALY=read_excel("数据.xlsx",sheet=5)
IHD_ASDALY_ts=ts(IHD_ASDALY$val,start=1990,frequency=1)
plot(IHD_ASDALY_ts)


fit4=auto.arima(IHD_ASDALY_ts)
fit4
summary(fit4)

forecasted_values4=forecast(fit4,h=29)
forecast_df4=data.frame(
  year=c(time(IHD_ASDALY_ts),time(forecasted_values4$mean)),
  value=c(as.numeric(IHD_ASDALY_ts),as.numeric(forecasted_values4$mean)),
  Type=c(rep("Actual",length(IHD_ASDALY_ts)),rep("Forecast",length(forecasted_values4$mean)))
)

p4=ggplot()+
  geom_line(data=forecast_df4,aes(x=year,y=value,color=Type),size=0.5)+
  geom_line(data = forecast_df4[forecast_df4$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5)+
  geom_point(data=forecast_df4[forecast_df4$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5,shape=21,
             fill="yellow",color="darkgray",stroke=0.5)+
  geom_ribbon(data=data.frame(
    year=time(forecasted_values4$mean),
    ymin=forecasted_values4$lower[,2],
    ymax=forecasted_values4$upper[,2]
  ),aes(x=year,ymin=ymin,ymax=ymax),fill="yellow",alpha=0.2)+
  geom_vline(xintercept = 2021,linetype="dashed",color="black",size=1)+
  scale_color_manual(values=c("Actual"="red","Forecast"="yellow"))+
  labs(title="ASDR of IHD",x="Year",y="ASDR(per 100,000)")+
  ylim(1000,3200)+
  theme_minimal()+
  theme(text = element_text(family = "Times New Roman", size = 10),
        axis.line = element_line(color = "darkgray"),
        plot.title = element_text(hjust = 0.5,vjust=1,face="bold",size=14),
        plot.margin = margin(3,3,3,3),
        axis.title.y = element_text(margin = margin(r = 10)))
plot(p4)   






Diabetes_mellitus_ASIR=read_excel("数据.xlsx",sheet=6)
Diabetes_mellitus_ASIR_ts=ts(Diabetes_mellitus_ASIR$val,start=1990,frequency=1)
plot(Diabetes_mellitus_ASIR_ts)


fit5=auto.arima(Diabetes_mellitus_ASIR_ts)
fit5
summary(fit5)

forecasted_values5=forecast(fit5,h=29)
forecast_df5=data.frame(
  year=c(time(Diabetes_mellitus_ASIR_ts),time(forecasted_values5$mean)),
  value=c(as.numeric(Diabetes_mellitus_ASIR_ts),as.numeric(forecasted_values5$mean)),
  Type=c(rep("Actual",length(Diabetes_mellitus_ASIR_ts)),rep("Forecast",length(forecasted_values5$mean)))
)

p5=ggplot()+
  geom_line(data=forecast_df5,aes(x=year,y=value,color=Type),size=0.5)+
  geom_line(data = forecast_df5[forecast_df5$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5)+
  geom_point(data=forecast_df5[forecast_df5$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5,shape=21,
             fill="yellow",color="darkgray",stroke=0.5)+
  geom_ribbon(data=data.frame(
    year=time(forecasted_values5$mean),
    ymin=forecasted_values5$lower[,2],
    ymax=forecasted_values5$upper[,2]
  ),aes(x=year,ymin=ymin,ymax=ymax),fill="yellow",alpha=0.2)+
  geom_vline(xintercept = 2021,linetype="dashed",color="black",size=1)+
  scale_color_manual(values=c("Actual"="red","Forecast"="yellow"))+
  labs(title="ASIR of T2DM",x="Year",y="ASIR(per 100,000)")+
  ylim(150,500)+
  theme_minimal()+
  theme(text = element_text(family = "Times New Roman", size = 10),
        axis.line = element_line(color = "darkgray"),
        plot.title = element_text(hjust = 0.5,vjust=1,face="bold",size=14),
        plot.margin = margin(3,3,3,3),
        axis.title.y = element_text(margin = margin(r = 10)))
plot(p5)   






Diabetes_mellitus_ASPR=read_excel("数据.xlsx",sheet=7)
Diabetes_mellitus_ASPR_ts=ts(Diabetes_mellitus_ASPR$val,start=1990,frequency=1)
plot(Diabetes_mellitus_ASPR_ts)


fit6=auto.arima(Diabetes_mellitus_ASPR_ts)
fit6
summary(fit6)

forecasted_values6=forecast(fit6,h=29)
forecast_df6=data.frame(
  year=c(time(Diabetes_mellitus_ASPR_ts),time(forecasted_values6$mean)),
  value=c(as.numeric(Diabetes_mellitus_ASPR_ts),as.numeric(forecasted_values6$mean)),
  Type=c(rep("Actual",length(Diabetes_mellitus_ASPR_ts)),rep("Forecast",length(forecasted_values6$mean)))
)

p6=ggplot()+
  geom_line(data=forecast_df6,aes(x=year,y=value,color=Type),size=0.5)+
  geom_line(data = forecast_df6[forecast_df6$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5)+
  geom_point(data=forecast_df6[forecast_df6$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5,shape=21,
             fill="yellow",color="darkgray",stroke=0.5)+
  geom_ribbon(data=data.frame(
    year=time(forecasted_values6$mean),
    ymin=forecasted_values6$lower[,2],
    ymax=forecasted_values6$upper[,2]
  ),aes(x=year,ymin=ymin,ymax=ymax),fill="yellow",alpha=0.2)+
  geom_vline(xintercept = 2021,linetype="dashed",color="black",size=1)+
  scale_color_manual(values=c("Actual"="red","Forecast"="yellow"))+
  labs(title="ASPR of T2DM",x="Year",y="ASPR(per 100,000)")+
  ylim(3200,15000)+
  theme_minimal() +
  theme(
    text = element_text(family = "Times New Roman", size = 10),
    axis.line = element_line(color = "darkgray"),
    plot.title = element_text(hjust = 0.5, vjust = 1, face = "bold", size = 14),
    plot.margin = margin(3, 3, 3, 3),
    axis.title.y = element_text(margin = margin(r = 10)),
    axis.text = element_text(face = "bold", color = "black")  # 新增：加粗黑色刻度标签
  )
plot(p6)





Diabetes_mellitus_ASDR=read_excel("数据.xlsx",sheet=8)
Diabetes_mellitus_ASDR_ts=ts(Diabetes_mellitus_ASDR$val,start=1990,frequency=1)
plot(Diabetes_mellitus_ASDR_ts)


fit7=auto.arima(Diabetes_mellitus_ASDR_ts)
fit7
summary(fit7)

forecasted_values7=forecast(fit7,h=29)
forecast_df7=data.frame(
  year=c(time(Diabetes_mellitus_ASDR_ts),time(forecasted_values7$mean)),
  value=c(as.numeric(Diabetes_mellitus_ASDR_ts),as.numeric(forecasted_values7$mean)),
  Type=c(rep("Actual",length(Diabetes_mellitus_ASDR_ts)),rep("Forecast",length(forecasted_values7$mean)))
)

p7=ggplot()+
  geom_line(data=forecast_df7,aes(x=year,y=value,color=Type),size=0.5)+
  geom_line(data = forecast_df7[forecast_df7$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5)+
  geom_point(data=forecast_df7[forecast_df7$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5,shape=21,
             fill="yellow",color="darkgray",stroke=0.5)+
  geom_ribbon(data=data.frame(
    year=time(forecasted_values7$mean),
    ymin=forecasted_values7$lower[,2],
    ymax=forecasted_values7$upper[,2]
  ),aes(x=year,ymin=ymin,ymax=ymax),fill="yellow",alpha=0.2)+
  geom_vline(xintercept = 2021,linetype="dashed",color="black",size=1)+
  scale_color_manual(values=c("Actual"="red","Forecast"="yellow"))+
  labs(title="ASMR of T2DM",x="Year",y="ASMR(per 100,000)")+
  ylim(10,25)+
  theme_minimal()+
  theme(text = element_text(family = "Times New Roman", size = 10),
        axis.line = element_line(color = "darkgray"),
        plot.title = element_text(hjust = 0.5,vjust=1,face="bold",size=14),
        plot.margin = margin(3,3,3,3),
        axis.title.y = element_text(margin = margin(r = 10)))
plot(p7)





Diabetes_mellitus_ASDALY=read_excel("数据.xlsx",sheet=9)
Diabetes_mellitus_ASDALY_ts=ts(Diabetes_mellitus_ASDALY$val,start=1990,frequency=1)
plot(Diabetes_mellitus_ASDALY_ts)


fit8=auto.arima(Diabetes_mellitus_ASDALY_ts)
fit8
summary(fit8)

forecasted_values8=forecast(fit8,h=29)
forecast_df8=data.frame(
  year=c(time(Diabetes_mellitus_ASDALY_ts),time(forecasted_values8$mean)),
  value=c(as.numeric(Diabetes_mellitus_ASDALY_ts),as.numeric(forecasted_values8$mean)),
  Type=c(rep("Actual",length(Diabetes_mellitus_ASDALY_ts)),rep("Forecast",length(forecasted_values8$mean)))
)

p8=ggplot()+
  geom_line(data=forecast_df8,aes(x=year,y=value,color=Type),size=0.5)+
  geom_line(data = forecast_df8[forecast_df8$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5)+
  geom_point(data=forecast_df8[forecast_df8$Type=="Forecast",],aes(x=year,y=value,color=Type),size=0.5,shape=21,
             fill="yellow",color="darkgray",stroke=0.5)+
  geom_ribbon(data=data.frame(
    year=time(forecasted_values8$mean),
    ymin=forecasted_values8$lower[,2],
    ymax=forecasted_values8$upper[,2]
  ),aes(x=year,ymin=ymin,ymax=ymax),fill="yellow",alpha=0.2)+
  geom_vline(xintercept = 2021,linetype="dashed",color="black",size=1)+
  scale_color_manual(values=c("Actual"="red","Forecast"="yellow"))+
  labs(title="ASDR of T2DM",x="Year",y="ASDR(per 100,000)")+
  ylim(650,1250)+
  theme_minimal()+
  theme(text = element_text(family = "Times New Roman", size = 10),
        axis.line = element_line(color = "darkgray"),
        plot.title = element_text(hjust = 0.5,vjust=1,face="bold",size=14),
        plot.margin = margin(3,3,3,3),
        axis.title.y = element_text(margin = margin(r = 10)))
plot(p8)