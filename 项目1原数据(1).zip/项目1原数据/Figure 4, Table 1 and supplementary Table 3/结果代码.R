###更改协变量#####
library(gt)
library(jstable)
library(forestploter)
library(zoo)
library(risksetROC)
library(patchwork)
library(kableExtra)
library(boot)
library(Hmisc)  # 用于计算 C-index
library(compareC)  # 可选，用于比较 C-index
library(rms)
library(haven)
library(plyr)
library(dplyr)
library(arsenal)
library(survey)
library(gtsummary)
library(tableone)
library(tidyverse)
library(tidyr)
library(survival)
library(survminer)
library(readr)
library(flextable)
library(ggplot2)
setwd("D:/r语言")

#提取DEMO数据####
demo_d <- read_xpt("DEMO_D.xpt")
demo_e <- read_xpt("DEMO_E.xpt")
demo_f <- read_xpt("DEMO_F.xpt")
demo_g <- read_xpt("DEMO_G.xpt")
demo_h <- read_xpt("DEMO_H.xpt")
demo_i <- read_xpt("DEMO_I.xpt")
# 提取所需变量
demo_vars <- c("SEQN", "RIAGENDR", "RIDAGEYR", "RIDRETH1", "DMDEDUC2", "INDFMPIR", "RIDEXPRG", "SDMVPSU", "SDMVSTRA", "WTMEC2YR", "WTINT2YR")

demo_d <- demo_d %>% select(all_of(demo_vars))
demo_e <- demo_e %>% select(all_of(demo_vars))
demo_f <- demo_f %>% select(all_of(demo_vars))
demo_g <- demo_g %>% select(all_of(demo_vars))
demo_h <- demo_h %>% select(all_of(demo_vars))
demo_i <- demo_i %>% select(all_of(demo_vars))
demo_d <- demo_d %>% mutate(cycle = "2005-2006")
demo_e <- demo_e %>% mutate(cycle = "2007-2008")
demo_f <- demo_f %>% mutate(cycle = "2009-2010")
demo_g <- demo_g %>% mutate(cycle = "2011-2012")
demo_h <- demo_h %>% mutate(cycle = "2013-2014")
demo_i <- demo_i %>% mutate(cycle = "2015-2016")
# 合并所有周期的数据
demo_combined <- bind_rows(demo_d, demo_e, demo_f, demo_g, demo_h, demo_i)
head(demo_combined)
dim(demo_combined)
# 读取 SMQ 数据####
smq_d <- read_xpt("SMQ_D.xpt")
smq_e <- read_xpt("SMQ_E.xpt")
smq_f <- read_xpt("SMQ_F.xpt")
smq_g <- read_xpt("SMQ_G.xpt")
smq_h <- read_xpt("SMQ_H.xpt")
smq_i <- read_xpt("SMQ_I.xpt")

# 提取 SMQ 所需的变量
smq_vars <- c("SEQN", "SMQ020", "SMQ040")  # 根据需要调整变量

smq_d <- smq_d %>% select(all_of(smq_vars))
smq_e <- smq_e %>% select(all_of(smq_vars))
smq_f <- smq_f %>% select(all_of(smq_vars))
smq_g <- smq_g %>% select(all_of(smq_vars))
smq_h <- smq_h %>% select(all_of(smq_vars))
smq_i <- smq_i %>% select(all_of(smq_vars))

# 为每个 SMQ 数据添加周期信息
smq_d <- smq_d %>% mutate(cycle = "2005-2006")
smq_e <- smq_e %>% mutate(cycle = "2007-2008")
smq_f <- smq_f %>% mutate(cycle = "2009-2010")
smq_g <- smq_g %>% mutate(cycle = "2011-2012")
smq_h <- smq_h %>% mutate(cycle = "2013-2014")
smq_i <- smq_i %>% mutate(cycle = "2015-2016")

# 合并所有周期的 SMQ 数据
smq_combined <- bind_rows(smq_d, smq_e, smq_f, smq_g, smq_h, smq_i)

# 将 SMQ 数据合并到 demo_combined 中
demo_combined <- demo_combined %>%
  left_join(smq_combined, by = c("SEQN", "cycle"))

# 查看合并后的数据
head(demo_combined)
dim(demo_combined)
# 读取 ALQ 数据####
alq_d <- read_xpt("ALQ_D.xpt")
alq_e <- read_xpt("ALQ_E.xpt")
alq_f <- read_xpt("ALQ_F.xpt")
alq_g <- read_xpt("ALQ_G.xpt")
alq_h <- read_xpt("ALQ_H.xpt")
alq_i <- read_xpt("ALQ_I.xpt")

# 提取 ALQ 所需的变量
alq_vars <- c("SEQN", "ALQ130", "ALQ120Q", "ALQ101", "ALQ110")  # 根据需要调整变量

alq_d <- alq_d %>% select(all_of(alq_vars))
alq_e <- alq_e %>% select(all_of(alq_vars))
alq_f <- alq_f %>% select(all_of(alq_vars))
alq_g <- alq_g %>% select(all_of(alq_vars))
alq_h <- alq_h %>% select(all_of(alq_vars))
alq_i <- alq_i %>% select(all_of(alq_vars))

# 为每个 ALQ 数据添加周期信息
alq_d <- alq_d %>% mutate(cycle = "2005-2006")
alq_e <- alq_e %>% mutate(cycle = "2007-2008")
alq_f <- alq_f %>% mutate(cycle = "2009-2010")
alq_g <- alq_g %>% mutate(cycle = "2011-2012")
alq_h <- alq_h %>% mutate(cycle = "2013-2014")
alq_i <- alq_i %>% mutate(cycle = "2015-2016")

# 合并所有周期的 ALQ 数据
alq_combined <- bind_rows(alq_d, alq_e, alq_f, alq_g, alq_h, alq_i)

# 将 ALQ 数据合并到 demo_combined 中
demo_combined <- demo_combined %>%
  left_join(alq_combined, by = c("SEQN", "cycle"))
# 查看合并后的数据
head(demo_combined)
dim(demo_combined)
# 读取 BMX 数据####
bmx_d <- read_xpt("BMX_D.xpt")
bmx_e <- read_xpt("BMX_E.xpt")
bmx_f <- read_xpt("BMX_F.xpt")
bmx_g <- read_xpt("BMX_G.xpt")
bmx_h <- read_xpt("BMX_H.xpt")
bmx_i <- read_xpt("BMX_I.xpt")

# 提取 BMX 所需的变量
bmx_vars <- c("SEQN", "BMXWAIST", "BMXBMI")  # 根据需要调整变量

bmx_d <- bmx_d %>% select(all_of(bmx_vars))
bmx_e <- bmx_e %>% select(all_of(bmx_vars))
bmx_f <- bmx_f %>% select(all_of(bmx_vars))
bmx_g <- bmx_g %>% select(all_of(bmx_vars))
bmx_h <- bmx_h %>% select(all_of(bmx_vars))
bmx_i <- bmx_i %>% select(all_of(bmx_vars))

# 为每个 BMX 数据添加周期信息
bmx_d <- bmx_d %>% mutate(cycle = "2005-2006")
bmx_e <- bmx_e %>% mutate(cycle = "2007-2008")
bmx_f <- bmx_f %>% mutate(cycle = "2009-2010")
bmx_g <- bmx_g %>% mutate(cycle = "2011-2012")
bmx_h <- bmx_h %>% mutate(cycle = "2013-2014")
bmx_i <- bmx_i %>% mutate(cycle = "2015-2016")

# 合并所有周期的 BMX 数据
bmx_combined <- bind_rows(bmx_d, bmx_e, bmx_f, bmx_g, bmx_h, bmx_i)

# 将 BMX 数据合并到 demo_combined 中
demo_combined <- demo_combined %>%
  left_join(bmx_combined, by = c("SEQN", "cycle"))

# 查看合并后的数据
head(demo_combined)
dim(demo_combined)
# 读取 BPX 数据####
bpx_d <- read_xpt("BPX_D.xpt")
bpx_e <- read_xpt("BPX_E.xpt")
bpx_f <- read_xpt("BPX_F.xpt")
bpx_g <- read_xpt("BPX_G.xpt")
bpx_h <- read_xpt("BPX_H.xpt")
bpx_i <- read_xpt("BPX_I.xpt")
# 提取 BPX 所需的变量
bpx_vars <- c("SEQN", "BPXSY1", "BPXSY2", "BPXSY3", "BPXSY4", "BPXDI1", "BPXDI2", "BPXDI3", "BPXDI4")  # 根据需要调整变量

bpx_d <- bpx_d %>% select(all_of(bpx_vars))
bpx_e <- bpx_e %>% select(all_of(bpx_vars))
bpx_f <- bpx_f %>% select(all_of(bpx_vars))
bpx_g <- bpx_g %>% select(all_of(bpx_vars))
bpx_h <- bpx_h %>% select(all_of(bpx_vars))
bpx_i <- bpx_i %>% select(all_of(bpx_vars))

# 为每个 BPX 数据添加周期信息
bpx_d <- bpx_d %>% mutate(cycle = "2005-2006")
bpx_e <- bpx_e %>% mutate(cycle = "2007-2008")
bpx_f <- bpx_f %>% mutate(cycle = "2009-2010")
bpx_g <- bpx_g %>% mutate(cycle = "2011-2012")
bpx_h <- bpx_h %>% mutate(cycle = "2013-2014")
bpx_i <- bpx_i %>% mutate(cycle = "2015-2016")

# 合并所有周期的 BPX 数据
bpx_combined <- bind_rows(bpx_d, bpx_e, bpx_f, bpx_g, bpx_h, bpx_i)

# 将 BPX 数据合并到 demo_combined 中
demo_combined <- demo_combined %>%
  left_join(bpx_combined, by = c("SEQN", "cycle"))

# 查看合并后的数据
head(demo_combined)
dim(demo_combined)
# 读取 DIQ 数据####
diq_d <- read_xpt("DIQ_D.xpt")
diq_e <- read_xpt("DIQ_E.xpt")
diq_f <- read_xpt("DIQ_F.xpt")
diq_g <- read_xpt("DIQ_G.xpt")
diq_h <- read_xpt("DIQ_H.xpt")
diq_i <- read_xpt("DIQ_I.xpt")
# 提取 DIQ 所需的变量
diq_vars <- c("SEQN", "DIQ010", "DID070", "DIQ160")  # 根据需要调整变量
diq_vars1 <- c("SEQN", "DIQ010", "DIQ070", "DIQ160")
diq_d <- diq_d %>% select(all_of(diq_vars))
diq_e <- diq_e %>% select(all_of(diq_vars))
diq_f <- diq_f %>% select(all_of(diq_vars1))
diq_g <- diq_g %>% select(all_of(diq_vars1))
diq_h <- diq_h %>% select(all_of(diq_vars1))
diq_i <- diq_i %>% select(all_of(diq_vars1))

# 为每个 DIQ 数据添加周期信息
diq_d <- diq_d %>% mutate(cycle = "2005-2006")
diq_e <- diq_e %>% mutate(cycle = "2007-2008")
diq_f <- diq_f %>% mutate(cycle = "2009-2010")
diq_g <- diq_g %>% mutate(cycle = "2011-2012")
diq_h <- diq_h %>% mutate(cycle = "2013-2014")
diq_i <- diq_i %>% mutate(cycle = "2015-2016")

# 合并所有周期的 DIQ 数据
diq_combined <- bind_rows(diq_d, diq_e, diq_f, diq_g, diq_h, diq_i)

# 将 DIQ 数据合并到 demo_combined 中
demo_combined <- demo_combined %>%
  left_join(diq_combined, by = c("SEQN", "cycle"))

# 查看合并后的数据
head(demo_combined)
dim(demo_combined)

# 读取 BPQ 数据####
bpq_d <- read_xpt("BPQ_D.xpt")
bpq_e <- read_xpt("BPQ_E.xpt")
bpq_f <- read_xpt("BPQ_F.xpt")
bpq_g <- read_xpt("BPQ_G.xpt")
bpq_h <- read_xpt("BPQ_H.xpt")
bpq_i <- read_xpt("BPQ_I.xpt")

# 提取 BPQ 所需的变量
bpq_vars <- c("SEQN", "BPQ020", "BPQ050A", "BPQ090D", "BPQ080", "BPQ040A")  # 根据需要调整变量

bpq_d <- bpq_d %>% select(all_of(bpq_vars))
bpq_e <- bpq_e %>% select(all_of(bpq_vars))
bpq_f <- bpq_f %>% select(all_of(bpq_vars))
bpq_g <- bpq_g %>% select(all_of(bpq_vars))
bpq_h <- bpq_h %>% select(all_of(bpq_vars))
bpq_i <- bpq_i %>% select(all_of(bpq_vars))

# 为每个 BPQ 数据添加周期信息
bpq_d <- bpq_d %>% mutate(cycle = "2005-2006")
bpq_e <- bpq_e %>% mutate(cycle = "2007-2008")
bpq_f <- bpq_f %>% mutate(cycle = "2009-2010")
bpq_g <- bpq_g %>% mutate(cycle = "2011-2012")
bpq_h <- bpq_h %>% mutate(cycle = "2013-2014")
bpq_i <- bpq_i %>% mutate(cycle = "2015-2016")

# 合并所有周期的 BPQ 数据
bpq_combined <- bind_rows(bpq_d, bpq_e, bpq_f, bpq_g, bpq_h, bpq_i)

# 将 BPQ 数据合并到 demo_combined 中
demo_combined <- demo_combined %>%
  left_join(bpq_combined, by = c("SEQN", "cycle"))
#假设 BPQ040A 或 BPQ050A 表示是否使用降压药（1 = 是，2 = 否）
#bpq_antihypertensive <- bpq_combined %>%
#filter(BPQ040A == 1 | BPQ050A == 1)  # 根据实际变量调整

# 查看合并后的数据
head(demo_combined)
dim(demo_combined)
# 读取 MCQ 数据####
mcq_d <- read_xpt("MCQ_D.xpt")
mcq_e <- read_xpt("MCQ_E.xpt")
mcq_f <- read_xpt("MCQ_F.xpt")
mcq_g <- read_xpt("MCQ_G.xpt")
mcq_h <- read_xpt("MCQ_H.xpt")
mcq_i <- read_xpt("MCQ_I.xpt")

# 提取 MCQ 所需的变量
mcq_vars <- c("SEQN", "MCQ160B", "MCQ160C", "MCQ160D", "MCQ160E", "MCQ160F", "MCQ220")  # 根据需要调整变量

mcq_d <- mcq_d %>% select(all_of(mcq_vars))
mcq_e <- mcq_e %>% select(all_of(mcq_vars))
mcq_f <- mcq_f %>% select(all_of(mcq_vars))
mcq_g <- mcq_g %>% select(all_of(mcq_vars))
mcq_h <- mcq_h %>% select(all_of(mcq_vars))
mcq_i <- mcq_i %>% select(all_of(mcq_vars))

# 为每个 MCQ 数据添加周期信息
mcq_d <- mcq_d %>% mutate(cycle = "2005-2006")
mcq_e <- mcq_e %>% mutate(cycle = "2007-2008")
mcq_f <- mcq_f %>% mutate(cycle = "2009-2010")
mcq_g <- mcq_g %>% mutate(cycle = "2011-2012")
mcq_h <- mcq_h %>% mutate(cycle = "2013-2014")
mcq_i <- mcq_i %>% mutate(cycle = "2015-2016")

# 合并所有周期的 MCQ 数据
mcq_combined <- bind_rows(mcq_d, mcq_e, mcq_f, mcq_g, mcq_h, mcq_i)

# 将 MCQ 数据合并到 demo_combined 中
demo_combined <- demo_combined %>%
  left_join(mcq_combined, by = c("SEQN", "cycle"))

# 查看合并后的数据
head(demo_combined)
dim(demo_combined)
# 读取 CBC 数据####
cbc_d <- read_xpt("CBC_D.xpt")
cbc_e <- read_xpt("CBC_E.xpt")
cbc_f <- read_xpt("CBC_F.xpt")
cbc_g <- read_xpt("CBC_G.xpt")
cbc_h <- read_xpt("CBC_H.xpt")
cbc_i <- read_xpt("CBC_I.xpt")

# 提取 CBC 所需的变量
cbc_vars <- c("SEQN", "LBXWBCSI", "LBXPLTSI", "LBXHGB")  # 根据需要调整变量

cbc_d <- cbc_d %>% select(all_of(cbc_vars))
cbc_e <- cbc_e %>% select(all_of(cbc_vars))
cbc_f <- cbc_f %>% select(all_of(cbc_vars))
cbc_g <- cbc_g %>% select(all_of(cbc_vars))
cbc_h <- cbc_h %>% select(all_of(cbc_vars))
cbc_i <- cbc_i %>% select(all_of(cbc_vars))

# 为每个 CBC 数据添加周期信息
cbc_d <- cbc_d %>% mutate(cycle = "2005-2006")
cbc_e <- cbc_e %>% mutate(cycle = "2007-2008")
cbc_f <- cbc_f %>% mutate(cycle = "2009-2010")
cbc_g <- cbc_g %>% mutate(cycle = "2011-2012")
cbc_h <- cbc_h %>% mutate(cycle = "2013-2014")
cbc_i <- cbc_i %>% mutate(cycle = "2015-2016")

# 合并所有周期的 CBC 数据
cbc_combined <- bind_rows(cbc_d, cbc_e, cbc_f, cbc_g, cbc_h, cbc_i)

# 将 CBC 数据合并到 demo_combined 中
demo_combined <- demo_combined %>%
  left_join(cbc_combined, by = c("SEQN", "cycle"))

# 查看合并后的数据
head(demo_combined)
dim(demo_combined)
# 读取 BIOPRO 数据####
biopro_d <- read_xpt("BIOPRO_D.xpt")
biopro_e <- read_xpt("BIOPRO_E.xpt")
biopro_f <- read_xpt("BIOPRO_F.xpt")
biopro_g <- read_xpt("BIOPRO_G.xpt")
biopro_h <- read_xpt("BIOPRO_H.xpt")
biopro_i <- read_xpt("BIOPRO_I.xpt")

# 提取 BIOPRO 所需的变量
biopro_vars <- c("SEQN", "LBXSATSI", "LBXSASSI", "LBXSCR", "LBXSGL")  # 根据需要调整变量

biopro_d <- biopro_d %>% select(all_of(biopro_vars))
biopro_e <- biopro_e %>% select(all_of(biopro_vars))
biopro_f <- biopro_f %>% select(all_of(biopro_vars))
biopro_g <- biopro_g %>% select(all_of(biopro_vars))
biopro_h <- biopro_h %>% select(all_of(biopro_vars))
biopro_i <- biopro_i %>% select(all_of(biopro_vars))

# 为每个 BIOPRO 数据添加周期信息
biopro_d <- biopro_d %>% mutate(cycle = "2005-2006")
biopro_e <- biopro_e %>% mutate(cycle = "2007-2008")
biopro_f <- biopro_f %>% mutate(cycle = "2009-2010")
biopro_g <- biopro_g %>% mutate(cycle = "2011-2012")
biopro_h <- biopro_h %>% mutate(cycle = "2013-2014")
biopro_i <- biopro_i %>% mutate(cycle = "2015-2016")

# 合并所有周期的 BIOPRO 数据
biopro_combined <- bind_rows(biopro_d, biopro_e, biopro_f, biopro_g, biopro_h, biopro_i)

# 将 BIOPRO 数据合并到 demo_combined 中
demo_combined <- demo_combined %>%
  left_join(biopro_combined, by = c("SEQN", "cycle"))

# 查看合并后的数据
head(demo_combined)
dim(demo_combined)

# 读取 GLU 数据####
glu_d <- read_xpt("GLU_D.xpt")
glu_e <- read_xpt("GLU_E.xpt")
glu_f <- read_xpt("GLU_F.xpt")
glu_g <- read_xpt("GLU_G.xpt")
glu_h <- read_xpt("GLU_H.xpt")
glu_i <- read_xpt("GLU_I.xpt")

# 提取 GLU 所需的变量
glu_vars <- c("SEQN", "LBDGLUSI", "LBXGLU")  # 根据需要调整变量

glu_d <- glu_d %>% select(all_of(glu_vars))
glu_e <- glu_e %>% select(all_of(glu_vars))
glu_f <- glu_f %>% select(all_of(glu_vars))
glu_g <- glu_g %>% select(all_of(glu_vars))
glu_h <- glu_h %>% select(all_of(glu_vars))
glu_i <- glu_i %>% select(all_of(glu_vars))

# 为每个 GLU 数据添加周期信息
glu_d <- glu_d %>% mutate(cycle = "2005-2006")
glu_e <- glu_e %>% mutate(cycle = "2007-2008")
glu_f <- glu_f %>% mutate(cycle = "2009-2010")
glu_g <- glu_g %>% mutate(cycle = "2011-2012")
glu_h <- glu_h %>% mutate(cycle = "2013-2014")
glu_i <- glu_i %>% mutate(cycle = "2015-2016")

# 合并所有周期的 GLU 数据
glu_combined <- bind_rows(glu_d, glu_e, glu_f, glu_g, glu_h, glu_i)

# 将 GLU 数据合并到 demo_combined 中
demo_combined <- demo_combined %>%
  left_join(glu_combined, by = c("SEQN", "cycle"))

# 查看合并后的数据
head(demo_combined)
dim(demo_combined)
# 读取 GHB 数据####
ghb_d <- read_xpt("GHB_D.xpt")
ghb_e <- read_xpt("GHB_E.xpt")
ghb_f <- read_xpt("GHB_F.xpt")
ghb_g <- read_xpt("GHB_G.xpt")
ghb_h <- read_xpt("GHB_H.xpt")
ghb_i <- read_xpt("GHB_I.xpt")

# 提取 GHB 所需的变量
ghb_vars <- c("SEQN", "LBXGH")  # 根据需要调整变量

ghb_d <- ghb_d %>% select(all_of(ghb_vars))
ghb_e <- ghb_e %>% select(all_of(ghb_vars))
ghb_f <- ghb_f %>% select(all_of(ghb_vars))
ghb_g <- ghb_g %>% select(all_of(ghb_vars))
ghb_h <- ghb_h %>% select(all_of(ghb_vars))
ghb_i <- ghb_i %>% select(all_of(ghb_vars))

# 为每个 GHB 数据添加周期信息
ghb_d <- ghb_d %>% mutate(cycle = "2005-2006")
ghb_e <- ghb_e %>% mutate(cycle = "2007-2008")
ghb_f <- ghb_f %>% mutate(cycle = "2009-2010")
ghb_g <- ghb_g %>% mutate(cycle = "2011-2012")
ghb_h <- ghb_h %>% mutate(cycle = "2013-2014")
ghb_i <- ghb_i %>% mutate(cycle = "2015-2016")

# 合并所有周期的 GHB 数据
ghb_combined <- bind_rows(ghb_d, ghb_e, ghb_f, ghb_g, ghb_h, ghb_i)

# 将 GHB 数据合并到 demo_combined 中
demo_combined <- demo_combined %>%
  left_join(ghb_combined, by = c("SEQN", "cycle"))

# 查看合并后的数据
head(demo_combined)
dim(demo_combined)
# 读取 TRIGLY 数据####
trigly_d <- read_xpt("TRIGLY_D.xpt")
trigly_e <- read_xpt("TRIGLY_E.xpt")
trigly_f <- read_xpt("TRIGLY_F.xpt")
trigly_g <- read_xpt("TRIGLY_G.xpt")
trigly_h <- read_xpt("TRIGLY_H.xpt")
trigly_i <- read_xpt("TRIGLY_I.xpt")

# 提取 TRIGLY 所需的变量
trigly_vars <- c("SEQN", "LBXTR", "LBDLDL")  # 根据需要调整变量

trigly_d <- trigly_d %>% select(all_of(trigly_vars))
trigly_e <- trigly_e %>% select(all_of(trigly_vars))
trigly_f <- trigly_f %>% select(all_of(trigly_vars))
trigly_g <- trigly_g %>% select(all_of(trigly_vars))
trigly_h <- trigly_h %>% select(all_of(trigly_vars))
trigly_i <- trigly_i %>% select(all_of(trigly_vars))

# 为每个 TRIGLY 数据添加周期信息
trigly_d <- trigly_d %>% mutate(cycle = "2005-2006")
trigly_e <- trigly_e %>% mutate(cycle = "2007-2008")
trigly_f <- trigly_f %>% mutate(cycle = "2009-2010")
trigly_g <- trigly_g %>% mutate(cycle = "2011-2012")
trigly_h <- trigly_h %>% mutate(cycle = "极佳-2014")
trigly_i <- trigly_i %>% mutate(cycle = "2015-2016")

# 合并所有周期的 TRIGLY 数据
trigly_combined <- bind_rows(trigly_d, trigly_e, trigly_f, trigly_g, trigly_h, trigly_i)

# 将 TRIGLY 数据合并到 demo_combined 中
demo_combined <- demo_combined %>%
  left_join(trigly_combined, by = c("SEQN", "cycle"))

# 查看合并后的数据
head(demo_combined)
dim(demo_combined)
# 读取 HDL 数据
hdl_d <- read_xpt("HDL_D.xpt")
hdl_e <- read_xpt("HDL_E.xpt")
hdl_f <- read_xpt("HDL_F.xpt")
hdl_g <- read_xpt("HDL_G.xpt")
hdl_h <- read_xpt("HDL_H.xpt")
hdl_i <- read_xpt("HDL_I.xpt")

# 提取 HDL 所需的变量####
hdl_vars <- c("SEQN", "LBDHDD")  # 根据需要调整变量

hdl_d <- hdl_d %>% select(all_of(hdl_vars))
hdl_e <- hdl_e %>% select(all_of(hdl_vars))
hdl_f <- hdl_f %>% select(all_of(hdl_vars))
hdl_g <- hdl_g %>% select(all_of(hdl_vars))
hdl_h <- hdl_h %>% select(all_of(hdl_vars))
hdl_i <- hdl_i %>% select(all_of(hdl_vars))

# 为每个 HDL 数据添加周期信息
hdl_d <- hdl_d %>% mutate(cycle = "2005-2006")
hdl_e <- hdl_e %>% mutate(cycle = "2007-2008")
hdl_f <- hdl_f %>% mutate(cycle = "2009-2010")
hdl_g <- hdl_g %>% mutate(cycle = "2011-2012")
hdl_h <- hdl_h %>% mutate(cycle = "2013-2014")
hdl_i <- hdl_i %>% mutate(cycle = "2015-2016")

# 合并所有周期的 HDL 数据
hdl_combined <- bind_rows(hdl_d, hdl_e, hdl_f, hdl_g, hdl_h, hdl_i)

# 将 HDL 数据合并到 demo_combined 中
demo_combined <- demo_combined %>%
  left_join(hdl_combined, by = c("SEQN", "cycle"))

# 查看合并后的数据
head(demo_combined)
dim(demo_combined)

# 读取 OGTT 数据####
ogtt_d <- read_xpt("OGTT_D.xpt")
ogtt_e <- read_xpt("OGTT_E.xpt")
ogtt_f <- read_xpt("OGTT_F.xpt")
ogtt_g <- read_xpt("OGTT_G.xpt")
ogtt_h <- read_xpt("OGTT_H.xpt")
ogtt_i <- read_xpt("OGTT_I.xpt")

# 提取 OGTT 所需的变量
ogtt_vars <- c("SEQN", "LBDGLTSI", "LBXGLT")  # 根据需要调整变量

ogtt_d <- ogtt_d %>% select(all_of(ogtt_vars))
ogtt_e <- ogtt_e %>% select(all_of(ogtt_vars))
ogtt_f <- ogtt_f %>% select(all_of(ogtt_vars))
ogtt_g <- ogtt_g %>% select(all_of(ogtt_vars))
ogtt_h <- ogtt_h %>% select(all_of(ogtt_vars))
ogtt_i <- ogtt_i %>% select(all_of(ogtt_vars))

# 为每个 OGTT 数据添加周期信息
ogtt_d <- ogtt_d %>% mutate(cycle = "2005-2006")
ogtt_e <- ogtt_e %>% mutate(cycle = "2007-2008")
ogtt_f <- ogtt_f %>% mutate(cycle = "2009-2010")
ogtt_g <- ogtt_g %>% mutate(cycle = "2011-2012")
ogtt_h <- ogtt_h %>% mutate(cycle = "2013-2014")
ogtt_i <- ogtt_i %>% mutate(cycle = "2015-2016")

# 合并所有周期的 OGTT 数据
ogtt_combined <- bind_rows(ogtt_d, ogtt_e, ogtt_f, ogtt_g, ogtt_h, ogtt_i)

# 将 OGTT 数据合并到 demo_combined 中
demo_combined <- demo_combined %>%
  left_join(ogtt_combined, by = c("SEQN", "cycle"))

# 查看合并后的数据
head(demo_combined)
dim(demo_combined)
# 读取所有周期的 RXQ 数据（处方药物记录）####
rxq_d <- read_xpt("RXQ_RX_D.xpt") %>% mutate(cycle = "2005-2006")
rxq_e <- read_xpt("RXQ_RX_E.xpt") %>% mutate(cycle = "2007-2008")
rxq_f <- read_xpt("RXQ_RX_F.xpt") %>% mutate(cycle = "2009-2010")
rxq_g <- read_xpt("RXQ_RX_G.xpt") %>% mutate(cycle = "2011-2012")
rxq_h <- read_xpt("RXQ_RX_H.xpt") %>% mutate(cycle = "2013-2014")
rxq_i <- read_xpt("RXQ_RX_I.xpt") %>% mutate(cycle = "2015-2016")
rxq_combined <- bind_rows(rxq_d, rxq_e, rxq_f, rxq_g, rxq_h, rxq_i)

######定义抗糖尿病药物关键词（根据药物名称匹配）#####
antidiabetic_keywords <- c(
  "insulin", "metformin", "glimepiride", "glipizide", "pioglitazone",
  "rosiglitazone", "sitagliptin", "alogliptin", "acarbose", "miglitol",
  "exenatide", "liraglutide", "dapagliflozin", "empagliflozin", "canagliflozin"
)
# 筛选抗糖尿病药物记录（忽略大小写）
rxq_antidiabetic <- rxq_combined %>%
  filter(str_detect(tolower(RXDDRUG), paste(antidiabetic_keywords, collapse = "|")))
# 提取唯一的药物使用者（基于SEQN）
antidiabetic_users_rxq <- rxq_antidiabetic %>%
  distinct(SEQN, cycle, .keep_all = TRUE)
# 合并 DIQ 和 RXQ 中的药物使用者
#antidiabetic_combined <- bind_rows(
#diq_combined %>% select(SEQN, cycle),
#antidiabetic_users_rxq %>% select(SEQN, cycle)
#) %>%
#distinct(SEQN, cycle)  # 去重
#####读取降血脂的药物#####
# 定义降脂药物关键词（他汀类、依泽替米贝、贝特类）
lipid_keywords <- c(
  "atorvastatin", "simvastatin", "pravastatin", "rosuvastatin", "lovastatin",
  "fluvastatin", "ezetimibe", "fenofibrate", "gemfibrozil", "bezafibrate",
  "pitavastatin", "clofibrate"
)
# 筛选降脂药物记录（忽略大小写）
rxq_lipid <- rxq_combined %>%
  filter(str_detect(tolower(RXDDRUG), paste(lipid_keywords, collapse = "|")))
# 提取唯一的药物使用者（每个周期每个个体保留一条记录）
lipid_users_rxq <- rxq_lipid %>%
  distinct(SEQN, cycle, .keep_all = TRUE)
#####提取降血压药物#####
# 定义降压药物关键词（ACEI/ARB/利尿剂/钙拮抗剂/β受体阻滞剂等）
htn_keywords <- c(
  "amlodipine", "lisinopril", "losartan", "valsartan", "hydrochlorothiazide",
  "atenolol", "metoprolol", "carvedilol", "diltiazem", "verapamil",
  "furosemide", "olmesartan", "irbesartan", "nebivolol", "spironolactone",
  "quinapril", "enalapril", "benazepril", "nifedipine", "felodipine"
)
# 筛选降压药物记录（忽略大小写）
rxq_htn <- rxq_combined %>%
  filter(str_detect(tolower(RXDDRUG), paste(htn_keywords, collapse = "|")))
# 提取唯一的药物使用者（每个周期每个个体保留一条记录）
htn_users_rxq <- rxq_htn %>%
  distinct(SEQN, cycle, .keep_all = TRUE)

demo_combined <- demo_combined %>%
  left_join(antidiabetic_users_rxq, by = c("SEQN", "cycle"))
demo_combined <- demo_combined %>%
  left_join(lipid_users_rxq, by = c("SEQN", "cycle"))
demo_combined <- demo_combined %>%
  left_join(htn_users_rxq, by = c("SEQN", "cycle"))
# 合并所有周期的 RXQ 数据，并添加周期标识

#####排除年龄小于 20 岁的样本#####
demo_combined_filtered <- demo_combined %>%
  filter(RIDAGEYR >= 45)
head(demo_combined_filtered)
dim(demo_combined_filtered)#60931-26751=34180
###########排除怀孕########
# 假设怀孕状态由变量 RIDEXPRG 表示，1 表示怀孕，2 表示未怀孕，NA 表示未知
# 排除怀孕的样本
demo_combined_filtered1 <- demo_combined_filtered %>%
  filter(RIDEXPRG != 1 | is.na(RIDEXPRG))
# 查看过滤后的数据
head(demo_combined_filtered1)
dim(demo_combined_filtered1)#34180-653=33527


########排除没有 waist circumference 数据的个体##########
demo_combined_with_meds_with_waist <- demo_combined_filtered1 %>%
  filter(!is.na(BMXWAIST))

# 查看排除后的数据
head(demo_combined_with_meds_with_waist)
dim(demo_combined_with_meds_with_waist)#6295-135=6160



########排除没有 hypertension 数据的个体########
demo_combined_with_meds_with_hypertension <- demo_combined_with_meds_with_waist %>%
  filter(!is.na(BPQ020))

# 查看排除后的数据
head(demo_combined_with_meds_with_hypertension)
dim(demo_combined_with_meds_with_hypertension)#6160

#######排除没有 glycated hemoglobin A1c 数据的个体########
demo_combined_with_meds_with_a1c <- demo_combined_with_meds_with_hypertension %>%
  filter(!is.na(LBXGH))

# 查看排除后的数据
head(demo_combined_with_meds_with_a1c)
dim(demo_combined_with_meds_with_a1c)#6160-12=6148

#########定义正常上限的 5 倍#######
alt_upper_limit <- 40 * 5
ast_upper_limit <- 40 * 5

# 排除有严重肝功能损害的参与者
demo_combined_with_meds_no_severe_liver <- demo_combined_with_meds_with_a1c %>%
  filter(LBXSATSI <= alt_upper_limit & LBXSASSI <= ast_upper_limit)

# 查看排除后的数据
head(demo_combined_with_meds_no_severe_liver)
dim(demo_combined_with_meds_no_severe_liver)#6148-58=6090

#######排除血压缺失#######
demo_combined_with_meds_no_renal_impairment <- demo_combined_with_meds_no_severe_liver %>%
  # 筛选所有血压变量均非缺失的行
  filter(
    complete.cases(BPXSY1, BPXSY2, BPXSY3, BPXDI1, BPXDI2, BPXDI3)
  )

# 查看处理后的数据概况
dim(demo_combined_with_meds_no_renal_impairment)#5313
######创建新变量 diff#####
demo_combined_with_meds <- demo_combined_with_meds_no_renal_impairment %>%
  mutate(diff = LBDGLTSI - LBDGLUSI)

# 查看添加新变量后的数据
head(demo_combined_with_meds)
######提取年龄并创建分类变量#####
# 提取 SEQN、年龄、性别、种族、教育水平并创建分类变量
paper.data <- demo_combined_with_meds %>%
  select(SEQN, RIDAGEYR, RIAGENDR, RIDRETH1, DMDEDUC2, INDFMPIR,SDMVPSU,SDMVSTRA,WTMEC2YR,WTINT2YR) %>%  # 提取 SEQN、年龄、性别、种族和教育水平列
  mutate(
    age_group = ifelse(RIDAGEYR >= 70, 1, 2),  # 创建年龄分类变量
    education_group = case_when(  # 创建教育水平分类变量
      DMDEDUC2 == 1 ~ 1,  # 高中以下
      DMDEDUC2 == 2 ~ 1,  # 高中或同等学历
      DMDEDUC2 == 3 ~ 2,  # 大学及以上
      DMDEDUC2 == 4 ~ 3,  # 大学及以上
      DMDEDUC2 == 5 ~ 3,  # 大学及以上
      TRUE ~ NA_real_  # 其他情况设为缺失值
    )
  ) #%>%
#filter(!is.na(education_group))  # 排除教育水平为缺失值的行

#######提取 SEQN、吸烟情况并创建分类变量######
smoking_data <- demo_combined_with_meds %>%
  select(SEQN, SMQ020, SMQ040) %>%  # 提取 SEQN 和吸烟相关列
  mutate(
    smoking_status = case_when(  # 创建吸烟情况分类变量
      SMQ020 == 2 ~ 3,  # 从未吸烟
      SMQ020 == 1 & SMQ040 == 2 ~ 2,  # 前吸烟者
      SMQ020 == 1 & SMQ040 == 1 ~ 1,  # 当前吸烟者
      TRUE ~ NA_real_  # 其他情况设为缺失值
    )
  ) %>%
  select(SEQN, smoking_status)  # 只保留 SEQN 和吸烟情况

# 将吸烟情况合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(smoking_data, by = "SEQN")  # 根据 SEQN 合并吸烟情况

#######提取 SEQN、酒精使用情况并创建分类变量#######
alcohol_data <- demo_combined_with_meds %>%
  select(SEQN, ALQ101, ALQ110) %>%  # 提取 SEQN 和酒精相关列
  mutate(
    alcohol_use = ifelse(ALQ101 == 1 | ALQ110 == 1, 1, 0)  # 创建二分类变量
  ) %>%
  select(SEQN, alcohol_use)  # 只保留 SEQN 和酒精使用情况

# 将酒精使用情况合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(alcohol_data, by = "SEQN")  # 根据 SEQN 合并酒精使用情况

######提取 SEQN、BMI、腰围、收缩压、舒张压######
health_data <- demo_combined_with_meds %>%
  select(SEQN, BMXBMI, BMXWAIST, BPXSY1, BPXDI1)  # 提取所需列

# 将健康数据合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(health_data, by = "SEQN")  # 根据 SEQN 合并健康数据

######提取 SEQN 和糖尿病相关变量#####
diabetes_data <- demo_combined_with_meds %>%
  select(SEQN, LBXGLU, LBXGH, LBXGLT, DIQ010, DIQ070, DID070) %>%
  mutate(
    diabetes = case_when(
      # 确诊或用药
      DIQ010 == 1 | DIQ070 == 1 | DID070 == 1 ~ 1,
      # 实验室标准（空腹血糖或HbA1c）
      (!is.na(LBXGLU) & LBXGLU >= 126) | (!is.na(LBXGH) & LBXGH >= 6.5) ~ 1,
      # OGTT 2小时血糖（如有数据）
      (!is.na(LBXGLT) & LBXGLT >= 200) ~ 1,
      # 明确无糖尿病
      DIQ010 == 2 & 
        (is.na(LBXGLU) | LBXGLU < 126) & 
        (is.na(LBXGH) | LBXGH < 6.5) ~ 0,
      # 其他情况保留NA
      TRUE ~ NA_real_
    )
  ) %>%
  select(SEQN, diabetes)

prediabetes_data <- demo_combined_with_meds %>%
  select(SEQN, LBXGLU, LBXSGL, LBXGLT, LBXGH, DIQ010, DIQ070, DID070, DIQ160) %>%  # 提取所需列
  mutate(
    LBXSGL = ifelse(is.na(LBXSGL), 9, LBXSGL),
    LBXGH = ifelse(is.na(LBXGH), 9, LBXGH),
    DID070 = ifelse(is.na(DID070), 9, DID070),
    DIQ160 = ifelse(is.na(DIQ160), 9, DIQ160),
    DIQ070 = ifelse(is.na(DIQ070), 9, DIQ070)# 将 NA 替换为 9
  ) %>%
  rowwise() %>%  # 按行计算
  mutate(
    prediabetes = ifelse(
      LBXGLU >= 100 & LBXGLU < 126 | LBXSGL >= 200 | LBXGLT >= 200 | LBXGH >= 5.7 & LBXGH < 6.5 | DIQ160 == 1,
      1, 0  # 满足任一条件则为糖尿病
    )
  ) %>%
  select(SEQN, prediabetes)  # 只保留 SEQN 和糖尿病分类变量


alldiabetes_data <- demo_combined_with_meds %>%
  select(SEQN, LBXGLU, LBXSGL, LBXGLT, LBXGH, DIQ010, DIQ070, DID070, DIQ160) %>%  # 提取所需列
  mutate(
    LBXSGL = ifelse(is.na(LBXSGL), 9, LBXSGL),
    LBXGH = ifelse(is.na(LBXGH), 9, LBXGH),
    DID070 = ifelse(is.na(DID070), 9, DID070),
    DIQ160 = ifelse(is.na(DIQ160), 9, DIQ160),
    DIQ070 = ifelse(is.na(DIQ070), 9, DIQ070)# 将 NA 替换为 9
  ) %>%
  rowwise() %>%  # 按行计算
  mutate(
    alldiabetes = ifelse(
      LBXGLU >= 100 | LBXSGL >= 200 | LBXGLT >= 200 | LBXGH >= 5.7 | DIQ010 == 1 | DIQ070 == 1 | DID070 == 1 | DIQ160 == 1,
      1, 0  # 满足任一条件则为糖尿病
    )
  ) %>%
  select(SEQN, alldiabetes)  # 只保留 SEQN 和糖尿病分类变量
# 将糖尿病分类变量合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(diabetes_data, by = "SEQN")
paper.data <- paper.data %>%
  left_join(prediabetes_data, by = "SEQN")# 根据 SEQN 合并糖尿病分类变量
paper.data <- paper.data %>%
  left_join(alldiabetes_data, by = "SEQN")# 根据 SEQN 合并糖尿病分类变量
##############ihd的定义###############
ihd_strict_data <- demo_combined_with_meds %>%
  mutate(
    IHD = case_when(
      # 明确的心肌梗死诊断
      MCQ160E == 1 ~ 1,
      
      # 冠状动脉疾病诊断+相关药物治疗
      MCQ160F == 1 ~ 1,
      
      # 心绞痛诊断+相关症状
      MCQ160B == 1 ~ 1,  # MCQ100: 胸痛症状
      
      # 默认无IHD
      TRUE ~ 0
    )
  ) %>%
  select(SEQN, IHD)
paper.data <- paper.data %>%
  left_join(ihd_strict_data, by = "SEQN")
view(paper.data)
######提取 SEQN 和高血压相关变量#######
# 提取 SEQN 和高血压相关变量
hypertension_data <- demo_combined_with_meds %>%
  select(SEQN, BPXSY1, BPXSY2, BPXSY3, BPXDI1, BPXDI2, BPXDI3, BPQ020, BPQ050A) %>%  # 提取所需列
  mutate(
    BPQ050A = ifelse(is.na(BPQ050A), 9, BPQ050A)  # 将 NA 替换为 9
  ) %>%
  rowwise() %>%  # 按行计算
  mutate(
    avg_sbp = mean(c(BPXSY1, BPXSY2, BPXSY3), na.rm = TRUE),  # 计算平均收缩压
    avg_dbp = mean(c(BPXDI1, BPXDI2, BPXDI3), na.rm = TRUE),  # 计算平均舒张压
    hypertension = ifelse(
      avg_sbp >= 140 | avg_dbp >= 90 | BPQ020 == 1 | BPQ050A == 1,
      1, 0  # 满足任一条件则为高血压
    )
  ) %>%
  select(SEQN, hypertension)  # 只保留 SEQN 和高血压分类变量

# 将高血压分类变量合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(hypertension_data, by = "SEQN")  # 根据 SEQN 合并高血压分类变量

#######提取 SEQN 和心血管疾病相关变量#######
cvd_data <- demo_combined_with_meds %>%
  select(SEQN, MCQ160B, MCQ160C, MCQ160D, MCQ160E, MCQ160F) %>%  # 提取所需列
  mutate(
    cvd = ifelse(
      MCQ160B == 1 | MCQ160C == 1 | MCQ160D == 1 | MCQ160E == 1 | MCQ160F == 1,
      1, 0  # 满足任一条件则为心血管疾病
    )
  ) %>%
  select(SEQN, cvd)  # 只保留 SEQN 和心血管疾病分类变量

# 将心血管疾病分类变量合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(cvd_data, by = "SEQN")  # 根据 SEQN 合并心血管疾病分类变量

########药物########
#######实验室数据#######
# 假设白细胞计数的数据在 demo_combined_with_meds 中，列名为 LBXWBCSI
white_blood_cells_data <- demo_combined_with_meds %>%
  select(SEQN, LBXWBCSI)  # 提取 SEQN 和白细胞计数列

# 将白细胞计数数据合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(white_blood_cells_data, by = "SEQN")  # 根据 SEQN 合并

# 假设血红蛋白的数据在 demo_combined_with_meds 中，列名为 LBXHGB
hemoglobin_data <- demo_combined_with_meds %>%
  select(SEQN, LBXHGB)  # 提取 SEQN 和血红蛋白列

# 将血红蛋白数据合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(hemoglobin_data, by = "SEQN")  # 根据 SEQN 合并

# 假设血小板计数的数据在 demo_combined_with_meds 中，列名为 LBXPLTSI
platelet_data <- demo_combined_with_meds %>%
  select(SEQN, LBXPLTSI)  # 提取 SEQN 和血小板计数列

# 将血小板计数数据合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(platelet_data, by = "SEQN")  # 根据 SEQN 合并

# 假设 ALT 的数据在 demo_combined_with_meds 中，列名为 LBXSAL
alt_data <- demo_combined_with_meds %>%
  select(SEQN, LBXSATSI)  # 提取 SEQN 和 ALT 列

# 将 ALT 数据合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(alt_data, by = "SEQN")  # 根据 SEQN 合并

# 假设 AST 的数据在 demo_combined_with_meds 中，列名为 LBXSAS
ast_data <- demo_combined_with_meds %>%
  select(SEQN, LBXSASSI)  # 提取 SEQN 和 AST 列

# 将 AST 数据合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(ast_data, by = "SEQN")  # 根据 SEQN 合并

# 假设血清肌酐的数据在 demo_combined_with_meds 中，列名为 LBXSCR
serum_creatinine_data <- demo_combined_with_meds %>%
  select(SEQN, LBXSCR)  # 提取 SEQN 和血清肌酐列

# 将血清肌酐数据合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(serum_creatinine_data, by = "SEQN")  # 根据 SEQN 合并

# 假设糖化血红蛋白的数据在 demo_combined_with_meds 中，列名为 LBXGH
serum_creatinine_data <- demo_combined_with_meds %>%
  select(SEQN, LBXGH)  # 提取 SEQN 和血清肌酐列

# 将血清肌酐数据合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(serum_creatinine_data, by = "SEQN")  # 根据 SEQN 合并

# 假设所需数据在 paper.data 中，列名分别为：
# 血清肌酐浓度：LBXSCR（单位：mg/dL）
# 年龄：RIDAGEYR
# 性别：RIAGENDR（1=Male, 2=Female）
# 种族：RIDRETH1（3=African American）

# 计算 eGFR
paper.data <- paper.data %>%
  mutate(
    eGFR = 186 * (LBXSCR)^(-1.154) * (RIDAGEYR)^(-0.203) *
      ifelse(RIAGENDR == 2, 0.742, 1) *  # 女性乘以 0.742
      ifelse(RIDRETH1 == 4, 1.210, 1)    # 非洲裔美国人乘以 1.210
  )



# 查看合并后的数据
head(paper.data)

#######假设所需数据在 paper.data 中，列名分别为########：

# 假设空腹血糖的数据在 demo_combined_with_meds 中，列名为 LBXSGL
fasting_glucose_data <- demo_combined_with_meds %>%
  select(SEQN, LBXSGL)  # 提取 SEQN 和空腹血糖列

# 将空腹血糖数据合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(fasting_glucose_data, by = "SEQN")  # 根据 SEQN 合并

# 假设空腹甘油三酯的数据在 demo_combined_with_meds 中，列名为 LBXSTR
fasting_triglyceride_data <- demo_combined_with_meds %>%
  select(SEQN, LBXTR)  # 提取 SEQN 和空腹甘油三酯列

# 将空腹甘油三酯数据合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(fasting_triglyceride_data, by = "SEQN")  # 根据 SEQN 合并

# 假设 HDL-C 的数据在 demo_combined_with_meds 中，列名为 LBDHDD
hdl_c_data <- demo_combined_with_meds %>%
  select(SEQN, LBDHDD)  # 提取 SEQN 和 HDL-C 列

# 将 HDL-C 数据合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(hdl_c_data, by = "SEQN")  # 根据 SEQN 合并

# 假设 LDL-C 的数据在 demo_combined_with_meds 中，列名为 LBDLDL
ldl_c_data <- demo_combined_with_meds %>%
  select(SEQN, LBDLDL)  # 提取 SEQN 和 LDL-C 列

# 将 LDL-C 数据合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(ldl_c_data, by = "SEQN")  # 根据 SEQN 合并

# 腰围：BMXWAIST
# 高血压：hypertension（1=Yes, 0=No）
# 糖化血红蛋白：LBXGH（假设为 HbA1c 的列名）

# 计算 eGDR
paper.data <- paper.data %>%
  mutate(
    eGDR = 21.158 - (0.09 * BMXWAIST) - (3.407 * hypertension) - (0.551 * LBXGH)
  )
paper.data <- paper.data %>%
  mutate(
    group = case_when(
      diabetes == 1 & IHD == 1 ~ 1,  # 糖尿病+冠心病
      diabetes == 1 & IHD == 0 ~ 2,  # 糖尿病无冠心病
      diabetes == 0 & IHD == 1 ~ 3,  # 冠心病无糖尿病
      diabetes == 0 & IHD == 0 ~ 4,  # 无糖尿病无冠心病
      TRUE ~ NA_real_               # 其他情况设为缺失
    )
  )
view(paper.data)
# 假设 diff 数据在 diff_data 中，列名为 diff
diff_data <- demo_combined_with_meds %>%
  select(SEQN, diff)  # 提取 SEQN 和 diff 列

# 将 diff 数据合并到 paper.data 中
paper.data <- paper.data %>%
  left_join(diff_data, by = "SEQN")  # 根据 SEQN 合并

# 将 diff 按四分位分组
paper.data <- paper.data %>%
  mutate(diff_quartile = ntile(diff, 4))  # 将 diff 分为 4 组

quantile(paper.data$diff, probs = c(0, 0.25, 0.5, 0.75, 1), na.rm = TRUE)

paper.data <- paper.data %>%
  mutate(
    # 分类变量转换为因子型
    RIAGENDR = as.factor(RIAGENDR),
    RIDRETH1 = as.factor(RIDRETH1),
    group = as.factor(group),
    DMDEDUC2 = as.factor(DMDEDUC2),
    age_group = as.factor(age_group),
    education_group = as.factor(education_group),
    smoking_status = as.factor(smoking_status),
    alcohol_use = as.factor(alcohol_use),
    diabetes = as.factor(diabetes),
    hypertension = as.factor(hypertension),
    cvd = as.factor(cvd),
    IHD = as.factor(IHD),
    prediabetes = as.factor(prediabetes),
    alldiabetes = as.factor(alldiabetes),
    diff_quartile = as.factor(diff_quartile),
    
    # 连续变量保持数值型
    RIDAGEYR = as.numeric(RIDAGEYR),
    SEQN = as.numeric(SEQN),
    SDMVSTRA = as.numeric(SDMVSTRA),
    SDMVPSU = as.numeric(SDMVPSU),
    WTMEC2YR = as.numeric(WTMEC2YR),
    INDFMPIR = as.numeric(INDFMPIR),
    BMXBMI = as.numeric(BMXBMI),
    BMXWAIST = as.numeric(BMXWAIST),
    BPXSY1 = as.numeric(BPXSY1),
    BPXDI1 = as.numeric(BPXDI1),
    LBXWBCSI = as.numeric(LBXWBCSI),
    LBXHGB = as.numeric(LBXHGB),
    LBXPLTSI = as.numeric(LBXPLTSI),
    LBXSATSI = as.numeric(LBXSATSI),
    LBXSCR = as.numeric(LBXSCR),
    LBXGH = as.numeric(LBXGH),
    eGFR = as.numeric(eGFR),
    LBXSGL = as.numeric(LBXSGL),
    LBXTR = as.numeric(LBXTR),
    LBDHDD = as.numeric(LBDHDD),
    LBDLDL = as.numeric(LBDLDL),
    eGDR = as.numeric(eGDR),
    diff = as.numeric(diff)
  )
paper.data <- paper.data %>%
  filter(!is.na(diabetes))
##########制作table1#########
# 创建 NHANES 设计对象
NHANES_design <- svydesign(
  id = ~SDMVPSU,  # 抽样单元（Primary Sampling Unit）
  strata = ~SDMVSTRA,  # 分层变量（Stratification Variable）
  weights = ~WTMEC2YR,  # 权重变量
  nest = TRUE,  # 是否嵌套
  data = paper.data  # 数据框
)

NHANES_data_labeled <- paper.data %>% 
  mutate(
    RIAGENDR = factor(RIAGENDR, levels = c(1, 2), labels = c("Male", "Female")),
    prediabetes = factor(prediabetes, levels = c(0, 1), labels = c("No", "Yes")),
    age_group = factor(age_group, levels = c(1, 2), labels = c("Age≥70", "Age<70")),
    education_group = factor(education_group, levels = c(1, 2, 3), labels = c("Less than high school", "High school or equivalent", "College or above")),
    smoking_status = factor(smoking_status, levels = c(1, 2, 3), labels = c("Current", "Former", "Never")),
    alcohol_use = factor(alcohol_use, levels = c(0, 1), labels = c("No", "Yes")),
    IHD = factor(IHD, levels = c(0, 1), labels = c("No", "Yes")),
    diabetes = factor(diabetes, levels = c(0, 1), labels = c("No", "Yes")),
    hypertension = factor(hypertension, levels = c(0, 1), labels = c("No", "Yes")),
    diff_quartile = factor(diff_quartile, levels = c(1, 2, 3, 4), labels = c("Q1", "Q2", "Q3", "Q4")),
    cvd = factor(cvd, levels = c(0, 1), labels = c("No", "Yes")),
    RIDRETH1 = factor(RIDRETH1, 
                      levels = c(1, 2, 3, 4, 5),
                      labels = c("Mexican American", "Other Hispanic", 
                                 "Non-Hispanic White", "Non-Hispanic Black",
                                 "Other Race"))
  )

# 重新创建调查设计对象
NHANES_design <- svydesign(
  ids = ~SDMVPSU,
  strata = ~SDMVSTRA,
  weights = ~WTINT2YR,
  nest = TRUE,
  data = NHANES_data_labeled
)




#view(paper.data)
table2 <- tbl_svysummary(
  NHANES_design,
  include = c( "diabetes","RIDAGEYR", "age_group", "RIAGENDR", "RIAGENDR", "RIDRETH1",
               "education_group", "INDFMPIR", "smoking_status", "alcohol_use",
               "BMXBMI", "BMXWAIST", "BPXSY1", "BPXDI1",
               "hypertension", "LBXWBCSI", "LBXHGB", "LBXPLTSI", 
               "LBXSATSI", "LBXSCR", "eGFR", "LBXSGL", "LBXGH", "LBXTR",
               "LBDHDD", "LBDLDL"),  # 移除 SEQN
  by = "IHD",  # 按 diff_quartile 分组
  missing = 'no',
  statistic = list(
    all_continuous() ~ "{mean} ± {sd}",  # 加权平均值±标准误差
    all_categorical() ~ "{n_unweighted} ({p_unweighted}%)"     # 未加权频率（加权比例）
  ),
  label = list(RIDAGEYR ~ 'Age, years',
               age_group ~ 'Age_group',
               RIAGENDR ~ 'Gender',
               RIDRETH1 ~ 'Ethnicity',
               education_group ~ 'Education level',
               INDFMPIR ~ 'Family PIR',
               smoking_status ~ 'Smoking',
               alcohol_use ~ 'Alcohol consumption',
               BMXBMI ~ 'BMI',
               BMXWAIST ~ 'Waist circumstance',
               BPXSY1 ~ 'SBP',
               BPXDI1 ~ 'DBP',
               hypertension ~ 'Hypertension',
               LBXWBCSI ~ 'White blood cells',
               LBXHGB ~ 'Hemoglobin',
               LBXPLTSI ~ 'Platelet',
               LBXSATSI ~ 'ALT',
               LBXSCR ~ 'Serum creatinine',
               eGFR ~ 'eGFR',
               LBXSGL ~ 'Fasting glucose',
               LBXGH ~ 'HbA1c',
               LBXTR ~ 'Fasting triglyceride',
               LBDHDD ~ 'HDL-C',
               LBDLDL ~ 'LDL-C',
               diabetes ~ 'T2DM'),
  digits = list(all_continuous() ~ 2, all_categorical() ~ 0)  # 设置小数位数
) %>%
  add_overall(statistic = list(
    all_continuous() ~ "{mean} ± {sd}",
    all_categorical() ~ "{n_unweighted} ({p_unweighted}%)"
  ),
  col_label = "**Overall  N=
  14208(100%)**"
  ) %>%  # 添加总体列
  add_p() %>%
  bold_labels() %>%  # 加粗变量标签
  modify_header(label = "**Variables**") %>%  # 修改表头
  modify_header(
    stat_1 = "No   N=\n{n_unweighted} ({style_percent(p_unweighted, symbol = TRUE)})",
    stat_2 = "Yes   N=\n{n_unweighted} ({style_percent(p_unweighted, symbol = TRUE)})"
  ) %>%
  modify_spanning_header(c("stat_1", "stat_2") ~ "**IHD**")  # 修改分组表头

# 查看 Table 2
table2
table2 %>%
  as_flex_table() %>%
  flextable::save_as_docx(
    path = "C:/Users/ROG/Desktop/result/table2.docx"
  )
####################患病率单因素#########
fit.1 <- svyglm(IHD ~ diabetes, design = NHANES_design,family = quasibinomial())
fit.2 <- svyglm(IHD ~ RIDAGEYR, design = NHANES_design,family = quasibinomial())
fit.3 <- svyglm(IHD ~ RIAGENDR, design = NHANES_design,family = quasibinomial())
fit.4 <- svyglm(IHD ~ RIDRETH1, design = NHANES_design,family = quasibinomial())
fit.5 <- svyglm(IHD ~ education_group, design = NHANES_design,family = quasibinomial())
fit.6 <- svyglm(IHD ~ INDFMPIR, design = NHANES_design,family = quasibinomial())
fit.7 <- svyglm(IHD ~ smoking_status, design = NHANES_design,family = quasibinomial())
fit.8 <- svyglm(IHD ~ alcohol_use, design = NHANES_design,family = quasibinomial())
fit.9 <- svyglm(IHD ~ BMXBMI, design = NHANES_design,family = quasibinomial())
fit.10 <- svyglm(IHD ~ BMXWAIST, design = NHANES_design,family = quasibinomial())
fit.11 <- svyglm(IHD ~ BPXSY1, design = NHANES_design,family = quasibinomial())
fit.12 <- svyglm(IHD ~ BPXDI1, design = NHANES_design,family = quasibinomial())
fit.13 <- svyglm(IHD ~ hypertension, design = NHANES_design,family = quasibinomial())
fit.14 <- svyglm(IHD ~ cvd, design = NHANES_design,family = quasibinomial())
fit.15 <- svyglm(IHD ~ LBXWBCSI, design = NHANES_design,family = quasibinomial())
fit.16 <- svyglm(IHD ~ LBXHGB, design = NHANES_design,family = quasibinomial())
fit.17 <- svyglm(IHD ~ LBXPLTSI, design = NHANES_design,family = quasibinomial())
fit.18 <- svyglm(IHD ~ LBXSATSI, design = NHANES_design,family = quasibinomial())
fit.19 <- svyglm(IHD ~ LBXSCR, design = NHANES_design,family = quasibinomial())
fit.20 <- svyglm(IHD ~ eGFR, design = NHANES_design,family = quasibinomial())
fit.21 <- svyglm(IHD ~ LBXSGL, design = NHANES_design,family = quasibinomial())
fit.22 <- svyglm(IHD ~ LBXGH, design = NHANES_design,family = quasibinomial())
fit.23 <- svyglm(IHD ~ LBXTR, design = NHANES_design,family = quasibinomial())
fit.24 <- svyglm(IHD ~ LBDHDD, design = NHANES_design,family = quasibinomial())
fit.25 <- svyglm(IHD ~ LBDLDL, design = NHANES_design,family = quasibinomial())
# 1. 血糖差异分级
tbl.1 <- tbl_regression(
  fit.1, 
  exponentiate = TRUE, 
  include = c(diabetes),
  label = list(diabetes ~ "T2DM"),  # 修改标签
  conf.level = 0.95
) %>% add_n() %>% add_global_p()

# 2. 年龄
tbl.2 <- tbl_regression(
  fit.2, 
  exponentiate = TRUE, 
  include = c(RIDAGEYR),
  label = list(RIDAGEYR ~ "Age, years"),  # 修改标签
  conf.level = 0.95
) %>% add_n() %>% add_global_p()

# 3. 性别
tbl.3 <- tbl_regression(
  fit.3, 
  exponentiate = TRUE, 
  include = c(RIAGENDR),
  label = list(RIAGENDR ~ "Gender"),  # 修改标签
  conf.level = 0.95
) %>% add_n() %>% add_global_p()

# 4. 种族
tbl.4 <- tbl_regression(
  fit.4, 
  exponentiate = TRUE, 
  include = c(RIDRETH1),
  label = list(RIDRETH1 ~ "Ethnicity"),  # 修改标签
  conf.level = 0.95
) %>% add_n() %>% add_global_p()

# 5. 教育程度
tbl.5 <- tbl_regression(
  fit.5, 
  exponentiate = TRUE, 
  include = c(education_group),
  label = list(education_group ~ "Education level"),  # 修改标签
  conf.level = 0.95
) %>% add_n() %>% add_global_p()

# 6. 家庭收入比
tbl.6 <- tbl_regression(
  fit.6, 
  exponentiate = TRUE, 
  include = c(INDFMPIR),
  label = list(INDFMPIR ~ "Family PIR"),  # 修改标签
  conf.level = 0.95
) %>% add_n() %>% add_global_p()

# 7. 吸烟状态
tbl.7 <- tbl_regression(
  fit.7, 
  exponentiate = TRUE, 
  include = c(smoking_status),
  label = list(smoking_status ~ "Smoking"),  # 修改标签
  conf.level = 0.95
) %>% add_n() %>% add_global_p()

# 8. 饮酒情况
tbl.8 <- tbl_regression(
  fit.8, 
  exponentiate = TRUE, 
  include = c(alcohol_use),
  label = list(alcohol_use ~ "Alcohol consumption"),  # 修改标签
  conf.level = 0.95
) %>% add_n() %>% add_global_p()

# 9-25. 其他变量（按相同模式修改）
tbl.9 <- tbl_regression(fit.9, exponentiate = TRUE, include = c(BMXBMI),
                        label = list(BMXBMI ~ "BMI"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.10 <- tbl_regression(fit.10, exponentiate = TRUE, include = c(BMXWAIST),
                         label = list(BMXWAIST ~ "Waist circumference"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.11 <- tbl_regression(fit.11, exponentiate = TRUE, include = c(BPXSY1),
                         label = list(BPXSY1 ~ "SBP"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.12 <- tbl_regression(fit.12, exponentiate = TRUE, include = c(BPXDI1),
                         label = list(BPXDI1 ~ "DBP"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.13 <- tbl_regression(fit.13, exponentiate = TRUE, include = c(hypertension),
                         label = list(hypertension ~ "Hypertension"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.14 <- tbl_regression(fit.14, exponentiate = TRUE, include = c(cvd),
                         label = list(cvd ~ "Cardiovascular diseases"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.15 <- tbl_regression(fit.15, exponentiate = TRUE, include = c(LBXWBCSI),
                         label = list(LBXWBCSI ~ "White blood cells"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.16 <- tbl_regression(fit.16, exponentiate = TRUE, include = c(LBXHGB),
                         label = list(LBXHGB ~ "Hemoglobin"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.17 <- tbl_regression(fit.17, exponentiate = TRUE, include = c(LBXPLTSI),
                         label = list(LBXPLTSI ~ "Platelet"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.18 <- tbl_regression(fit.18, exponentiate = TRUE, include = c(LBXSATSI),
                         label = list(LBXSATSI ~ "ALT"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.19 <- tbl_regression(fit.19, exponentiate = TRUE, include = c(LBXSCR),
                         label = list(LBXSCR ~ "Serum creatinine"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.20 <- tbl_regression(fit.20, exponentiate = TRUE, include = c(eGFR),
                         label = list(eGFR ~ "eGFR"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.21 <- tbl_regression(fit.21, exponentiate = TRUE, include = c(LBXSGL),
                         label = list(LBXSGL ~ "Fasting glucose"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.22 <- tbl_regression(fit.22, exponentiate = TRUE, include = c(LBXGH),
                         label = list(LBXGH ~ "HbA1c"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.23 <- tbl_regression(fit.23, exponentiate = TRUE, include = c(LBXTR),
                         label = list(LBXTR ~ "Fasting triglyceride"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.24 <- tbl_regression(fit.24, exponentiate = TRUE, include = c(LBDHDD),
                         label = list(LBDHDD ~ "HDL-C"), conf.level = 0.95) %>% add_n() %>% add_global_p()

tbl.25 <- tbl_regression(fit.25, exponentiate = TRUE, include = c(LBDLDL),
                         label = list(LBDLDL ~ "LDL-C"), conf.level = 0.95) %>% add_n() %>% add_global_p()
# 合并表格
merged_1.16 <- tbl_stack(list(tbl.1, tbl.2, tbl.3, tbl.4,tbl.5,tbl.6,tbl.7,tbl.8,tbl.9,tbl.10,tbl.11,tbl.12,tbl.13,tbl.14,tbl.15,tbl.16,tbl.17,tbl.18,tbl.19,tbl.20,tbl.21,tbl.22,tbl.23,tbl.24,tbl.25))%>%
  bold_labels() #%>% as_flex_table()
merged_1.16
# 将合并后的 gtsummary 表格转为 flextable
merged_flex <- as_flex_table(merged_1.16)
save_as_docx(
  merged_flex,
  path = "C:/Users/ROG/Desktop/result/merged_tables.docx"  # 替换为你的目标路径
)


####################患病率多因素############
model0.a <- svyglm(IHD ~ diabetes, design = NHANES_design, family = quasibinomial())

model1.a <- svyglm(IHD ~ diabetes + RIDAGEYR + RIAGENDR + RIDRETH1, design = NHANES_design, family = quasibinomial())

model2.a <- svyglm(IHD ~ diabetes + RIDAGEYR + RIAGENDR + RIDRETH1 + education_group+ smoking_status + BMXBMI + BMXWAIST + BPXSY1 + hypertension  + LBXWBCSI + LBXHGB + LBXSATSI + LBXPLTSI + eGFR+ LBDHDD, design = NHANES_design, family = quasibinomial())

# 提取 diff.group 的整体 p 值（相当于趋势检验）
p_trend0 <- regTermTest(model0.a, "diabetes")$p[1]
p_trend1 <- regTermTest(model1.a, "diabetes")$p[1]
p_trend2 <- regTermTest(model2.a, "diabetes")$p[1]

#通用函数：添加p-trend行
add_p_trend <- function(tbl, p_value) {
  tbl %>%
    modify_table_body(
      ~ {
        new_row <- tibble(
          variable = "p_trend",
          var_type = "intercept",
          var_label = "P for trend",
          label = "P for trend",
          estimate = NA_real_,
          conf.low = NA_real_,
          conf.high = NA_real_,
          p.value = p_value,
          row_type = "level"
        )
        bind_rows(.x, new_row)
      }
    ) %>%
    modify_fmt_fun(
      update = list(p.value = function(x) ifelse(x < 0.001, "<0.001", sprintf("%.3f", x)))
    )
}

# Model 0
tbl1.a <- tbl_regression(
  model0.a, 
  exponentiate = TRUE,
  include = c(diabetes),
  label = list(diabetes ~ "T2DM"),  # 修改标签
  conf.level = 0.95
) %>%
  modify_header(label = "**Morbidity**") %>%
  modify_table_body(~ .x %>% mutate(var_label = ifelse(variable == "diabetes", NA, var_label))) %>%
  add_p_trend(p_trend0) %>%
  add_n()

# Model 1
tbl2.a <- tbl_regression(
  model1.a, 
  exponentiate = TRUE,
  include = c(diabetes),
  label = list(diabetes ~ "T2DM"),  # 修改标签
  conf.level = 0.95
) %>%
  modify_header(label = "**Morbidity**") %>%
  modify_table_body(~ .x %>% mutate(var_label = ifelse(variable == "diabetes", NA, var_label))) %>%
  add_p_trend(p_trend1) %>%
  add_n()

# Model 2
tbl3.a <- tbl_regression(
  model2.a, 
  exponentiate = TRUE,
  include = c(diabetes),
  label = list(diabetes ~ "T2DM"),  # 修改标签
  conf.level = 0.95
) %>%
  modify_header(label = "**Morbidity**") %>%
  modify_table_body(~ .x %>% mutate(var_label = ifelse(variable == "diabetes", NA, var_label))) %>%
  add_p_trend(p_trend2) %>%
  add_n()

# 合并表格（其余代码不变）
merged_tbl.a <- tbl_merge(
  list(tbl1.a, tbl2.a, tbl3.a),
  tab_spanner = c("Model 1", "Model 2", "Model 3")
) %>%
  modify_footnote(
    everything() ~ "Association Between IHD and T2DM:
    
                   Model 1: Unadjusted; 
                   
                   Model 2 Adjusted for Age, Gender, Race;
                   
                   Model 3 Adjusted for Age, Gender, Race, Education level, Smoking, Waist circumference, SBP, DBP, Hypertension, White blood cells, Hemoglobin, ALT, Serum creatinine, eGFR, Fasting glucose, HDL-C"
  ) %>%
  bold_labels()
#model2.a <- svyglm(IHD ~ diabetes + RIDAGEYR + RIAGENDR + RIDRETH1 + education_group+ smoking_status + BMXBMI + BMXWAIST + BPXSY1 + hypertension  + LBXWBCSI + LBXHGB + LBXSATSI + LBXPLTSI + eGFR  + LBXTR + LBDHDD, design = NHANES_design, family = quasibinomial())
merged_tbl.a
merged_flex <- as_flex_table(merged_tbl.a)
save_as_docx(
  merged_flex,
  path = "C:/Users/ROG/Desktop/result/merged_tables111.docx"  # 替换为你的目标路径
)

NHSMortRead <- function(file.path){
  srvyin <- file.path   # full .DAT name here
  srvyout <- "data" # shorthand dataset name here
  
  # Example syntax:
  #srvyin <- paste("NHANES_1999_2000_MORT_2019_PUBLIC.dat")   
  #srvyout <- "NHANES_1999_2000"      
  
  
  # read in the fixed-width format ASCII file
  dsn <- read_fwf(file=srvyin,
                  col_types = "iiiiiiii",
                  fwf_cols(seqn = c(1,6),
                           eligstat = c(15,15),
                           mortstat = c(16,16),
                           ucod_leading = c(17,19),
                           diabetes = c(20,20),
                           hyperten = c(21,21),
                           permth_int = c(43,45),
                           permth_exm = c(46,48)
                  ),
                  na = c("", ".")
  )
  
  # NOTE:   SEQN is the unique ID for NHANES.
  
  # Structure and contents of data
  str(dsn)
  
  
  # Variable frequencies
  
  #ELIGSTAT: Eligibility Status for Mortality Follow-up
  table(dsn$eligstat)
  #1 = "Eligible"
  #2 = "Under age 18, not available for public release"
  #3 = "Ineligible"
  
  #MORTSTAT: Final Mortality Status
  table(dsn$mortstat, useNA="ifany")
  # 0 = Assumed alive
  # 1 = Assumed deceased
  # <NA> = Ineligible or under age 18
  
  #UCOD_LEADING: Underlying Cause of Death: Recode
  table(dsn$ucod_leading, useNA="ifany")
  # 1 = Diseases of heart (I00-I09, I11, I13, I20-I51)
  # 2 = Malignant neoplasms (C00-C97)
  # 3 = Chronic lower respiratory diseases (J40-J47)
  # 4 = Accidents (unintentional injuries) (V01-X59, Y85-Y86)
  # 5 = Cerebrovascular diseases (I60-I69)
  # 6 = Alzheimer's disease (G30)
  # 7 = Diabetes mellitus (E10-E14)
  # 8 = Influenza and pneumonia (J09-J18)
  # 9 = Nephritis, nephrotic syndrome and nephrosis (N00-N07, N17-N19, N25-N27)
  # 10 = All other causes (residual)
  # <NA> = Ineligible, under age 18, assumed alive, or no cause of death data available
  
  #DIABETES: Diabetes Flag from Multiple Cause of Death (MCOD)
  table(dsn$diabetes, useNA="ifany")
  # 0 = No - Condition not listed as a multiple cause of death
  # 1 = Yes - Condition listed as a multiple cause of death
  # <NA> = Assumed alive, under age 18, ineligible for mortality follow-up, or MCOD not available
  
  #HYPERTEN: Hypertension Flag from Multiple Cause of Death (MCOD)
  table(dsn$hyperten, useNA="ifany")
  # 0 = No - Condition not listed as a multiple cause of death
  # 1 = Yes - Condition listed as a multiple cause of death
  # <NA> = Assumed alive, under age 18, ineligible for mortality follow-up, or MCOD not available
  
  # Re-name the dataset, DSN, to the short survey name then remove other R objects
  assign(paste0(srvyout), dsn)
  rm(dsn, srvyin, srvyout)
  # View(data)
  return(data)
}

####读取生存分析数据######
mort.data_2005_2006 <- NHSMortRead('NHANES_2005_2006_MORT_2019_PUBLIC.dat')
mort.data_2007_2008 <- NHSMortRead('NHANES_2007_2008_MORT_2019_PUBLIC.dat')
mort.data_2009_2010 <- NHSMortRead('NHANES_2009_2010_MORT_2019_PUBLIC.dat')
mort.data_2011_2012 <- NHSMortRead('NHANES_2011_2012_MORT_2019_PUBLIC.dat')
mort.data_2013_2014 <- NHSMortRead('NHANES_2013_2014_MORT_2019_PUBLIC.dat')
mort.data_2015_2016 <- NHSMortRead('NHANES_2015_2016_MORT_2019_PUBLIC.dat')
colnames(mort.data_2005_2006) <- toupper(colnames(mort.data_2005_2006))
colnames(mort.data_2007_2008) <- toupper(colnames(mort.data_2007_2008))
colnames(mort.data_2009_2010) <- toupper(colnames(mort.data_2009_2010))
colnames(mort.data_2011_2012) <- toupper(colnames(mort.data_2011_2012))
colnames(mort.data_2013_2014) <- toupper(colnames(mort.data_2013_2014))
colnames(mort.data_2015_2016) <- toupper(colnames(mort.data_2015_2016))
# 合并所有死亡率数据
mort.data_all <- rbind(
  mort.data_2005_2006,
  mort.data_2007_2008,
  mort.data_2009_2010,
  mort.data_2011_2012,
  mort.data_2013_2014,
  mort.data_2015_2016
)
dim(mort.data_all)
# 合并数据
merged_data <- merge(paper.data, mort.data_all, by = "SEQN", all.x = TRUE)



####diff差值分为四小组######
# 创建分组变量
# 创建 cvd_mortality 变量
merged_data <- merged_data %>%
  mutate(
    cvd_mortality = ifelse(
      MORTSTAT == 1 & UCOD_LEADING ==1,  # 死亡且死亡原因为心血管疾病
      1,  # 心血管死亡
      0   # 非心血管死亡
    )
  )

merged_data <- merged_data %>%
  mutate(
    diff_group_hl = ifelse(diff < 2.886, 1, 2),
    eGDR_group_hl = ifelse(eGDR <= 4, 1, 2)
  )
merged_data <- merged_data %>%
  mutate(
    group_hl = case_when(
      diff_group_hl == 1 & eGDR_group_hl == 2 ~ 1,
      diff_group_hl == 2 & eGDR_group_hl == 2 ~ 2,
      diff_group_hl == 1 & eGDR_group_hl == 1 ~ 3,
      diff_group_hl == 2 & eGDR_group_hl == 1 ~ 4
    )
  )

merged_data <- merged_data %>%
  mutate(
    subgroup = case_when(
      RIAGENDR == 1 & diabetes == 2 ~ 1,  # 男性无糖尿病
      RIAGENDR == 1 & diabetes == 1 ~ 2,    # 男性有糖尿病
      RIAGENDR == 2 & diabetes == 2 ~ 3,  # 女性无糖尿病
      RIAGENDR == 2 & diabetes == 1 ~ 4     # 女性有糖尿病
    )
  )

# 使用 cut() 函数将 eGFR 分为四组
merged_data$eGDR_group <- cut(
  merged_data$eGDR,
  breaks = c(-Inf, 4, 6, 8, Inf),  # 定义分组区间
  labels = c(1, 2, 3, 4),          # 定义分组标签
  right = FALSE                    # 区间为左闭右开
)
length(merged_data$eGDR_group)

merged_data <- merged_data %>%
  mutate(
    # 分类变量转换为因子型
    diff_group_hl = as.factor(diff_group_hl),
    eGDR_group_hl = as.factor(eGDR_group_hl),
    subgroup = as.factor(subgroup),
    eGDR_group = as.factor(eGDR_group),
    group_hl = as.factor(group_hl)
  )

NHANES_data_labeled <- merged_data %>% 
  mutate(
    RIAGENDR = factor(RIAGENDR, levels = c(1, 2), labels = c("Male", "Female")),
    prediabetes = factor(prediabetes, levels = c(0, 1), labels = c("No", "Yes")),
    age_group = factor(age_group, levels = c(1, 2), labels = c("Age≥70", "Age<70")),
    education_group = factor(education_group, levels = c(1, 2, 3), labels = c("Less than high school", "High school or equivalent", "College or above")),
    smoking_status = factor(smoking_status, levels = c(1, 2, 3), labels = c("Current", "Former", "Never")),
    alcohol_use = factor(alcohol_use, levels = c(0, 1), labels = c("No", "Yes")),
    hypertension = factor(hypertension, levels = c(0, 1), labels = c("No", "Yes")),
    diff_quartile = factor(diff_quartile, levels = c(1, 2, 3, 4), labels = c("Q1", "Q2", "Q3", "Q4")),
    group = factor(group, levels = c(1, 2, 3, 4), labels = c("daibetes with ihd", "daibetes without ihd", "no daibetes with ihd", "no daibetes without ihd")),
    cvd = factor(cvd, levels = c(0, 1), labels = c("No", "Yes")),
    RIDRETH1 = factor(RIDRETH1, 
                      levels = c(1, 2, 3, 4, 5),
                      labels = c("Mexican American", "Other Hispanic", 
                                 "Non-Hispanic White", "Non-Hispanic Black",
                                 "Other Race"))
  )

# 重新创建调查设计对象
NHANES_design <- svydesign(
  ids = ~SDMVPSU,
  strata = ~SDMVSTRA,
  weights = ~WTINT2YR,
  nest = TRUE,
  data = NHANES_data_labeled
)

####################全因死亡率############
# 筛选 prediabetes=1 的数据
prediabetes_data <- subset(merged_data, prediabetes == 1)

# 创建生存对象
surv_obj_prediabetes <- Surv(merged_data$PERMTH_INT, merged_data$MORTSTAT)

# 拟合 Kaplan-Meier 模型
km_fit_prediabetes <- survfit(surv_obj_prediabetes ~ group, 
                              data = merged_data, 
                              weights = WTINT2YR)

# 查看模型摘要
summary(km_fit_prediabetes)

# 绘制 Kaplan-Meier 曲线
ggsurvplot(
  km_fit_prediabetes,
  data = merged_data,
  pval = TRUE,          # 显示 p 值
  conf.int = TRUE,      # 显示置信区间
  palette = "hue",      # 颜色主题
  xlab = "Time (months)",  # x 轴标签
  ylab = "Survival Probability",  # y 轴标签
  title = "All-cause mortality",  # 图表标题
  legend.title = "Quartiles of group",  # 图例标题
  legend.labs = c("T2DM with IHD", "T2DM without IHD", "no T2DM with IHD", "no T2DM without IHD")  # 图例标签
)
####################亚组分析森林图 ######
options(repos = c(CRAN = "https://mirrors.tuna.tsinghua.edu.cn/CRAN/"))
nhanesSUI_design <- svydesign(
  id = ~SDMVPSU,
  strata = ~SDMVSTRA,
  weights = ~WTMEC2YR,
  nest = TRUE,
  data = NHANES_data_labeled
)
sub.plot <- TableSubgroupMultiCox(formula = Surv(PERMTH_INT, MORTSTAT) ~ diff,
                                  var_subgroups = c("age_group","RIAGENDR", "RIDRETH1", "education_group", "smoking_status",
                                                    "alcohol_use",
                                                    "hypertension"),
                                  data = nhanesSUI_design)

# 修改变量名标签
sub.plot$Variable <- recode(sub.plot$Variable,
                            "age_group" = "Age_group",
                            "RIAGENDR" = "Gender",
                            "RIDRETH1" = "Ethnicity",
                            "education_group" = "Education Level",
                            "smoking_status" = "Smoking",
                            "alcohol_use" = "Alcohol Use",
                            "hypertension" = "Hypertension"
)


sub.plot[,c(2,3,7,8)][is.na(sub.plot[,c(2,3,7,8)])] <- " "

# 添加空白列，用于存放森林图的图形部分
sub.plot$' ' <- paste(rep(" ", nrow(sub.plot)), collapse = " ")

sub.plot[, c(2, 4, 5, 6)] <- lapply(sub.plot[, c(2, 4, 5, 6)], function(x) {
  if (is.factor(x)) as.numeric(as.character(x)) else as.numeric(x)
})

# 计算HR (95% CI)，以便显示在图形中
sub.plot$"HR (95% CI)" <- ifelse(is.na(sub.plot$"Point Estimate"), "", 
                                 sprintf("%.2f (%.2f to %.2f)", 
                                         sub.plot$"Point Estimate", 
                                         sub.plot$Lower, 
                                         sub.plot$Upper))

# 第一行Overall放在最后显示
sub.plot <- rbind(sub.plot[-1,],sub.plot[1,])

# Percent列重命名，加上%
sub.plot <- rename(sub.plot, 'Percent(%)' = Percent)
# 在创建森林图之前，修改数据框中的NA值为空字符串
sub.plot[, c("Count", "Percent(%)", "HR (95% CI)", "P value")] <- lapply(
  sub.plot[, c("Count", "Percent(%)", "HR (95% CI)", "P value")], 
  function(x) ifelse(is.na(x) | x == "NA", "", x)
)
# 森林图的格式设置
# 创建一个森林图主题，命名为tm
tm <- forest_theme(
  base_size = 10,  # 基本字体大小设置为10
  ci_pch = 15,  # 置信区间点形状设置为15（实心方块）
  #ci_col = "#762a83",  # 置信区间颜色设置为紫色（此行已注释）
  ci_col = "black",  # 置信区间颜色设置为黑色
  ci_fill = "black",  # 置信区间填充颜色设置为黑色
  ci_alpha = 0.8,  # 置信区间透明度设置为0.8
  ci_lty = 1,  # 置信区间线型设置为实线
  ci_lwd = 1.5,  # 置信区间线宽设置为1.5
  ci_Theight = 0.2,  # 置信区间横线高度设置为0.2
  refline_gp = gpar(lwd = 1, lty = "dashed", col = "grey20"),  # 参考线线宽设置为1# 参考线线型设置为虚线# 参考线颜色设置为灰色
  vertline_lwd = -0.1,  # 垂直线线宽设置为-0.1（隐藏）
  vertline_lty = "dashed",# 垂直线线型设置为虚线
  vertline_col = "red",  # 垂直线颜色设置为红色
  summary_fill = "blue",  # 汇总部分填充颜色设置为蓝色
  summary_col = "#4575b4",# 汇总部分颜色设置为深蓝色
  footnote_gp = gpar(cex = 0.6, fontface = "italic", col = "grey20"),  # 注脚字体大小设置为0.6# 注脚字体样式设置为斜体# 注脚颜色设置为灰色
)

#森林图绘制
plot.sub <- forest(data = sub.plot[, c(1, 2, 3, 9, 10, 7, 8)],
                   lower = sub.plot$Lower,  #置信区间下限
                   upper = sub.plot$Upper,  #置信区间上限
                   est = sub.plot$`Point Estimate`,  #点估计值
                   sizes = sub.plot$se*0.15,
                   ci_column = 4,  #点估计对应的列
                   ref_line = 1,  #设置参考线位置
                   xlim = c(0, 2),  # x轴的范围
                   ticks_at = c(0,2,1,0.5,1.5),
                   theme = tm
)
plot.sub
####################死亡率基线表###############
NHANES_filtered <- NHANES_data_labeled %>%
  filter(prediabetes == "Yes", !is.na(MORTSTAT))
nrow(NHANES_filtered)
nhanes_design_prediabetes <- svydesign(
  id = ~SDMVPSU,
  strata = ~SDMVSTRA,
  weights = ~WTMEC2YR,
  nest = TRUE,
  data = NHANES_filtered
)
nhanes_design_prediabetes$variables$MORTSTAT <- factor(
  nhanes_design_prediabetes$variables$MORTSTAT,
  levels = c(0, 1),
  labels = c("Surviving", "Deceased")
)

table3 <- tbl_svysummary(
  nhanes_design_prediabetes,
  include = c( "diff_quartile","RIDAGEYR", "age_group", "RIAGENDR", "RIAGENDR", "RIDRETH1",
               "education_group", "INDFMPIR", "smoking_status", "alcohol_use",
               "BMXBMI", "BMXWAIST", "BPXSY1", "BPXDI1",
               "hypertension", "cvd", "LBXWBCSI", "LBXHGB", "LBXPLTSI", 
               "LBXSATSI", "LBXSCR", "eGFR", "LBXSGL", "LBXGH", "LBXTR",
               "LBDHDD", "LBDLDL"),  # 移除 SEQN
  by = "MORTSTAT",  # 按 diff_quartile 分组
  missing = 'no',
  statistic = list(
    all_continuous() ~ "{mean} ± {sd}",  # 加权平均值±标准误差
    all_categorical() ~ "{n_unweighted} ({p_unweighted}%)"     # 未加权频率（加权比例）
  ),
  label = list(RIDAGEYR ~ 'Age, years',
               age_group ~ 'Age_group',
               RIAGENDR ~ 'Gender',
               RIDRETH1 ~ 'Ethnicity',
               education_group ~ 'Education level',
               INDFMPIR ~ 'Family PIR',
               smoking_status ~ 'Smoking',
               alcohol_use ~ 'Alcohol consumption',
               BMXBMI ~ 'BMI',
               BMXWAIST ~ 'Waist circumstance',
               BPXSY1 ~ 'SBP',
               BPXDI1 ~ 'DBP',
               hypertension ~ 'Hypertension',
               cvd ~ 'Cardiovascular diseases',
               LBXWBCSI ~ 'White blood cells',
               LBXHGB ~ 'Hemoglobin',
               LBXPLTSI ~ 'Platelet',
               LBXSATSI ~ 'ALT',
               LBXSCR ~ 'Serum creatinine',
               eGFR ~ 'eGFR',
               LBXSGL ~ 'Fasting glucose',
               LBXGH ~ 'HbA1c',
               LBXTR ~ 'Fasting triglyceride',
               LBDHDD ~ 'HDL-C',
               LBDLDL ~ 'LDL-C',
               diff_quartile ~ 'Blood glucose difference'),
  digits = list(all_continuous() ~ 2, all_categorical() ~ 0)  # 设置小数位数
) %>%
  add_overall(statistic = list(
    all_continuous() ~ "{mean} ± {sd}",
    all_categorical() ~ "{n_unweighted} ({p_unweighted}%)"
  ),
  col_label = "**Overall  N=
  3643(100%)**"
  ) %>%  # 添加总体列
  add_p() %>%
  bold_labels() %>%  # 加粗变量标签
  modify_header(label = "**Variables**") %>%  # 修改表头
  modify_header(
    stat_1 = "Surviving   N=\n{n_unweighted} ({style_percent(p_unweighted, symbol = TRUE)})",
    stat_2 = "Deceased   N=\n{n_unweighted} ({style_percent(p_unweighted, symbol = TRUE)})"
  ) %>%
  modify_spanning_header(c("stat_1", "stat_2") ~ "**Mortality Status**")  # 修改分组表头

# 查看 Table 2
table3
table3 %>%
  as_flex_table() %>%
  flextable::save_as_docx(
    path = "C:/Users/ROG/Desktop/result/table333333.docx"
  )
